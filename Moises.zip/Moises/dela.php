<?php 

	
	
	require_once('config.php');



	

	





$sql1 = "DELETE FROM `Open_Trades` WHERE Account_Number='".$_POST["accnum"]."' ";
	  // $result11=$con->query($sql1);	

if($con->query($sql1)){   

	echo "1";


}




?>