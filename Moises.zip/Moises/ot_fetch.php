<?php session_start();

if(isset($_SESSION['id']) && isset($_SESSION['username'])){
 
}
else{
    
    header("Location: login.php");
}

   require_once('config.php');

   date_default_timezone_set("Asia/Kolkata");

?>




  
 



<?php
 

  

   $sql1 = "SELECT * FROM Open_Trades WHERE 1  group by Account_Number ";
   $result1=$con->query($sql1);
   while($row1 = $result1->fetch_assoc()) {


    $strRequest = $_POST["data"];
    $strRequest= str_replace("[","",$strRequest);
    $strRequest= str_replace("]","",$strRequest);
    $strRequest= str_replace("\"","",$strRequest);

    $arr = [$strRequest];
    $text = $strRequest;

 // for ($i=0; $i <sizeof($arr) ; $i++) { 
 //  echo $arr[$i];
 // }

      $sumpro = 0;
      $tot = 0;

    $sql12 = "SELECT SUM(Order_Profit) as pro FROM Open_Trades WHERE Account_Number='".$row1["Account_Number"]."' ";
   $result12=$con->query($sql12);
   while($row12 = $result12->fetch_assoc()) {
    $sumpro = $row12["pro"];
   }

   $sql13 = "SELECT COUNT(*) as tot FROM Open_Trades WHERE Account_Number='".$row1["Account_Number"]."' ";
   $result13=$con->query($sql13);
   while($row13 = $result13->fetch_assoc()) {
    $tot = $row13["tot"];
   }


    // $actloss = $row1["Account_Balance"]*100/$sumpro;

    $actloss = ( $sumpro * 100  )  /    $row1["Account_Balance"];

    if($actloss>=0){


      if($actloss=="INF" || $actloss==INF ){

         echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.$row1["Account_Number"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.round($row1["Account_Balance"], 2). '&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: #0d4257;font-size:13px;">NA</b>

       

      <i class="fa fa-plus picon1"></i>
      <i class="fa fa-minus micon dnone"></i>

      <span style="float: right;    font-size: 12px;
    margin-right: 10px;
    ">'.$tot.'</span>
    </button>';

   

      if (strpos($text, $row1["Account_Number"]) !== false) {
    
        echo'<div class="coldiv r1div" style="display:block;">';

      }else{
        echo'<div class="coldiv r1div">';
      }

      }else{

        if(round($actloss, 5)== "0" || round($actloss, 5)== "-0" || round($actloss, 5)== "+0" ){

            echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.$row1["Account_Number"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.round($row1["Account_Balance"], 2). '&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: #0d4257;font-size:13px;">'.round($actloss, 5).'%</b>

       

      <i class="fa fa-plus picon1"></i>
      <i class="fa fa-minus micon dnone"></i>

      <span style="float: right;    font-size: 12px;
    margin-right: 10px;
    ">'.$tot.'</span>
    </button>';


    
     if (strpos($text, $row1["Account_Number"]) !== false) {
    
        echo'<div class="coldiv r1div" style="display:block;">';

      }else{
        echo'<div class="coldiv r1div ">';
      }

        }else{




         echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.$row1["Account_Number"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.round($row1["Account_Balance"], 2). '&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: green;font-size:13px;">'.round($actloss, 5).'%</b>

       

      <i class="fa fa-plus picon1"></i>
      <i class="fa fa-minus micon dnone"></i>

      <span style="float: right;    font-size: 12px;
    margin-right: 10px;
    ">'.$tot.'</span>
    </button>';


    
     if (strpos($text, $row1["Account_Number"]) !== false) {
    
        echo'<div class="coldiv r1div" style="display:block;">';

      }else{
        echo'<div class="coldiv r1div ">';
      }


      }




       }
      

    }else{

      if($actloss=="INF" || $actloss==INF ){

         echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.$row1["Account_Number"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.round($row1["Account_Balance"], 2). '&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: #0d4257;font-size:13px;">NA</b>

      

      <i class="fa fa-plus picon1"></i>
      <i class="fa fa-minus micon dnone"></i>

      <span style="float: right;    font-size: 12px;
    margin-right: 10px;
    ">'.$tot.'</span>

    </button>';
    
    if (strpos($text, $row1["Account_Number"]) !== false) {
    
        echo'<div class="coldiv r1div" style="display:block;">';

      }else{
        echo'<div class="coldiv r1div ">';
      }


      }else{

        if(round($actloss, 5)== "0" || round($actloss, 5)== "-0" || round($actloss, 5)== "+0" ){

           echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.$row1["Account_Number"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.round($row1["Account_Balance"], 2). '&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: #0d4257;font-size:13px;">'.round($actloss, 5).'%</b>

      

      <i class="fa fa-plus picon1"></i>
      <i class="fa fa-minus micon dnone"></i>

      <span style="float: right;    font-size: 12px;
    margin-right: 10px;
    ">'.$tot.'</span>

    </button>';
    
     if (strpos($text, $row1["Account_Number"]) !== false) {
    
        echo'<div class="coldiv r1div" style="display:block;">';

      }else{
        echo'<div class="coldiv r1div ">';
      }

        }else{

         echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.$row1["Account_Number"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.round($row1["Account_Balance"], 2). '&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: red;font-size:13px;">'.round($actloss, 5).'%</b>

      

      <i class="fa fa-plus picon1"></i>
      <i class="fa fa-minus micon dnone"></i>

      <span style="float: right;    font-size: 12px;
    margin-right: 10px;
    ">'.$tot.'</span>

    </button>';
    
     if (strpos($text, $row1["Account_Number"]) !== false) {
    
        echo'<div class="coldiv r1div" style="display:block;">';

      }else{
        echo'<div class="coldiv r1div ">';
      }


      }


    }
      

    }

   

    echo '<table class="table table-bordered" class="table">
    <thead>
  <tr>
    <th><center>Sl.No.</center></th>
    
    
    <th>Ticket </th>
    <th>Symbol</th>
    <th>Type</th>
    <th>Lots </th>
    <th>Stop Loss</th>
    <th>Take Profit</th>
    
    <th>Open Price</th>
    <th>Open&nbsp;Time&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
    <th>Current Price</th>
    
    <th>Swap</th>
    <th>Commission</th>
    <th>Profit</th>
    <th>Comment</th>
    <th>Magic Number</th>
   
  </tr>
</thead>
<tbody>';


$i1 = 1;

   $sql = "SELECT * FROM Open_Trades WHERE Account_Number='".$row1["Account_Number"]."' order by Order_Symbol asc ";
   $result=$con->query($sql);
   while($row = $result->fetch_assoc()) {

    $tot++;


   echo "<tr class='tr' id='".$row["SN"]."''>";
  
    echo "<td>".$i1."</td>";
    // echo "<td>".$row["Broker_Name"]."</td>";
    // echo "<td>".$row["Account_Number"]."</td>";
    echo "<td>".$row["Order_Ticket"]."</td>";
    echo "<td>".$row["Order_Symbol"]."</td>";


    if($row["Order_Type"]=="BUY"){

     echo "<td style='background: lightgreen;'>Buy</td>";

   }else{
    echo "<td style='background: #f59a9a;'>Sell</td>";
   }

    echo "<td class='righta'>".round($row["Order_Lots"],2)."</td>";
    echo "<td class='righta'>".round($row["Order_StopLoss"],5)."</td>";
    echo "<td class='righta'>".round($row["Order_TakeProfit"],5)."</td>";
    // echo "<td>".$row["Order_Expiration"]."</td>";
    echo "<td class='righta'>".round($row["Order_OpenPrice"],5)."</td>";
    echo "<td>".$row["Order_OpenTime"]."</td>";
    echo "<td class='righta'>".round($row["Order_ClosePrice"],5)."</td>";
    // echo "<td>".$row["Order_CloseTime"]."</td>";
    echo "<td class='righta'>".round($row["Order_Swap"],5)."</td>";
    echo "<td class='righta'>".round($row["Order_Commission"],5)."</td>";



    $op = round($row["Order_Profit"], 2);

     if($op>=0){
      echo "<td class='righta' style='background: lightgreen;'>".$op."</td>";
     }else{
      echo "<td class='righta' style='background: #f59a9a;'>".$op."</td>";
     }

    

    echo "<td>".$row["Order_Comment"]."</td>";
    echo "<td style='text-align: left;'>".$row["Order_MagicNumber"]."</td>";
   
    

    
    echo "</tr>";

    $i1++;

  }


echo '</tbody>
</table>';


    echo'</div><br><br>';

   }


    ?>


 















