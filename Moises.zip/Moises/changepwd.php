<?php session_start();


 // Create connection
   require_once('config.php');


if (!$con) {
    echo "Error: " . mysqli_connect_error();
	exit();
}





$pass=$_POST['changepwd'];


	// $sql1 = "UPDATE `QA_admin` SET `Password`='".$password."' WHERE 1" ;

$sql1 = "UPDATE `login` SET `Password`='".$pass."' WHERE `Username`='".$_SESSION['username']."' " ;
	
	 	 	
	if ($con->query($sql1))
		echo $sql1;

	
?>
