<?php

	define('DB_HOSTNAME', '127.0.0.1');

	define('DB_USERNAME', 'urak6s3guownx');

	define('DB_PASSWORD', 'cwnmi8fcglgh');

	define('DB_DATABASE', 'dbgpmuno4twfef');

	// define('DB_HOSTNAME', '127.0.0.1');

	// define('DB_USERNAME', 'root');

	// define('DB_PASSWORD', '');

	// define('DB_DATABASE', 'Trading');

	
	// define('DB_HOSTNAME', 'mysql201.phy.lolipop.lan');

	// define('DB_USERNAME', 'LAA0907153');

	// define('DB_PASSWORD', 'GkdrFf5k8NSsESgi');

	// define('DB_DATABASE', 'LAA0907153-livedata');


	$con = mysqli_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD,DB_DATABASE);

	if ($con->connect_error) {
		die("Connection failed: " . $con->connect_error);
	} 

?>


