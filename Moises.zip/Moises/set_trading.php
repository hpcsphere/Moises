<?php 

define('DB_HOSTNAME', '127.0.0.1');

	define('DB_USERNAME', 'urak6s3guownx');

	define('DB_PASSWORD', 'cwnmi8fcglgh');

	define('DB_DATABASE', 'dbgpmuno4twfef');

	// define('DB_HOSTNAME', '127.0.0.1');

	// define('DB_USERNAME', 'root');

	// define('DB_PASSWORD', '');

	// define('DB_DATABASE', 'Trading');

	$con = mysqli_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD,DB_DATABASE);

	if ($con->connect_error) {
		die("Connection failed: " . $con->connect_error);
	} 


	
	
   if( isset($_GET['Date']) && isset($_GET['Symbol']) && isset($_GET['Entry_Price']) && isset($_GET['Signal']) ){

   	$result = $con->query("SELECT * FROM Trad WHERE Date='".$_GET['Date']."' and Symbol='".$_GET['Symbol']."' and Entry_Price='".$_GET['Entry_Price']."' and `Signal`='".$_GET['Signal']."' ");

   	if( mysqli_num_rows($result)>0){
   		 $sql = "UPDATE `Trad` SET `execute`='true' WHERE Date='".$_GET['Date']."' and Symbol='".$_GET['Symbol']."' and Entry_Price='".$_GET['Entry_Price']."' and `Signal`='".$_GET['Signal']."' ";
	  $result1=$con->query($sql);	
	  echo 1;

   	}else{
   		echo -1;
   		
   	}

   }else{
  
   	echo -1;
   }




?>