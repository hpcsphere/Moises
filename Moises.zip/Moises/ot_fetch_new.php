<?php
 
 require_once('config.php');

 date_default_timezone_set("Asia/Kolkata");

  $acc = $_POST['acc'];
  $arr = array();
   

   $sql1 = "SELECT * FROM Open_Trades WHERE Account_Number='".$acc."' order by Order_Symbol asc ";
   $result1=$con->query($sql1);
   while($row = $result1->fetch_assoc()) {

    $sumpro = 0;
    $tot = 0;



   $sql12 = "SELECT SUM(Order_Profit) as pro FROM Open_Trades WHERE Account_Number='".$row["Account_Number"]."' ";
   $result12=$con->query($sql12);
   while($row12 = $result12->fetch_assoc()) {
    $sumpro = $row12["pro"];
   }

   $sql13 = "SELECT COUNT(*) as tot FROM Open_Trades WHERE Account_Number='".$row["Account_Number"]."' ";
   $result13=$con->query($sql13);
   while($row13 = $result13->fetch_assoc()) {
    $tot = $row13["tot"];
   }

   // $actloss = ( $sumpro * 100  )  /    $row["Account_Balance"];

   $actloss = $row["UnrealisedProfitPercentage"];

   if($actloss>=0){
    if($actloss=="INF" || $actloss==INF || $actloss==null ){
        
         array_push($arr, array('Broker_Name' => $row['Broker_Name'],'Account_Number' => $row['Account_Number'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Order_Ticket' => $row['Order_Ticket'], 'Order_Symbol' => $row['Order_Symbol'], 'Order_Type' => $row['Order_Type'], 'Order_Lots' => number_format($row["Order_Lots"], 2,".",""), 'Order_StopLoss' => round($row["Order_StopLoss"],5), 'Order_TakeProfit' => round($row["Order_TakeProfit"],5), 'Order_Expiration' => $row['Order_Expiration'], 'Order_OpenPrice' => round($row["Order_OpenPrice"],5), 'Order_OpenTime' => $row['Order_OpenTime'], 'Order_ClosePrice' => round($row["Order_ClosePrice"],5)."<span style='display:none;' id='cps".$row["Order_Ticket"]."'>".$row["cps"]."</span>", 'Order_CloseTime' => $row['Order_CloseTime'], 'Order_Swap' => round($row["Order_Swap"],5), 'Order_Commission' => round($row["Order_Commission"],5), 'Order_Profit' => number_format($row["Order_Profit"], 2,".",""), 'Order_Comment' => $row['Order_Comment'], 'Order_MagicNumber' => $row['Order_MagicNumber'], 'Cal' => '<span style="color:#0d4257;">NA</span>', 'Tot' => $tot, 'Datet' => date('d-M-Y h:i:s',strtotime($row["DateTime"])), 'Datet1' => date('d-M-Y H:i:s',strtotime($row["DateTime"])), 'Order_ClosePrice1' => round($row["Order_ClosePrice"],5) ));
    }else{
       

         if(round($actloss, 5)== "0" || round($actloss, 5)== "-0" || round($actloss, 5)== "+0" ){

            array_push($arr, array('Broker_Name' => $row['Broker_Name'],'Account_Number' => $row['Account_Number'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Order_Ticket' => $row['Order_Ticket'], 'Order_Symbol' => $row['Order_Symbol'], 'Order_Type' => $row['Order_Type'], 'Order_Lots' => number_format($row["Order_Lots"], 2,".",""), 'Order_StopLoss' => round($row["Order_StopLoss"],5), 'Order_TakeProfit' => round($row["Order_TakeProfit"],5), 'Order_Expiration' => $row['Order_Expiration'], 'Order_OpenPrice' => round($row["Order_OpenPrice"],5), 'Order_OpenTime' => $row['Order_OpenTime'], 'Order_ClosePrice' => round($row["Order_ClosePrice"],5)."<span style='display:none;' id='cps".$row["Order_Ticket"]."'>".$row["cps"]."</span>", 'Order_CloseTime' => $row['Order_CloseTime'], 'Order_Swap' => round($row["Order_Swap"],5), 'Order_Commission' => round($row["Order_Commission"],5), 'Order_Profit' => number_format($row["Order_Profit"], 2,".",""), 'Order_Comment' => $row['Order_Comment'], 'Order_MagicNumber' => $row['Order_MagicNumber'], 'Cal' => '<span style="color:#0d4257;">'.number_format($actloss, 2,".","").' %</span>', 'Tot' => $tot, 'Datet' => date('d-M-Y h:i:s',strtotime($row["DateTime"])), 'Datet1' => date('d-M-Y H:i:s',strtotime($row["DateTime"])), 'Order_ClosePrice1' => round($row["Order_ClosePrice"],5) ));

         }else{
            array_push($arr, array('Broker_Name' => $row['Broker_Name'],'Account_Number' => $row['Account_Number'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Order_Ticket' => $row['Order_Ticket'], 'Order_Symbol' => $row['Order_Symbol'], 'Order_Type' => $row['Order_Type'], 'Order_Lots' => number_format($row["Order_Lots"], 2,".",""), 'Order_StopLoss' => round($row["Order_StopLoss"],5), 'Order_TakeProfit' => round($row["Order_TakeProfit"],5), 'Order_Expiration' => $row['Order_Expiration'], 'Order_OpenPrice' => round($row["Order_OpenPrice"],5), 'Order_OpenTime' => $row['Order_OpenTime'], 'Order_ClosePrice' => round($row["Order_ClosePrice"],5)."<span style='display:none;' id='cps".$row["Order_Ticket"]."'>".$row["cps"]."</span>", 'Order_CloseTime' => $row['Order_CloseTime'], 'Order_Swap' => round($row["Order_Swap"],5), 'Order_Commission' => round($row["Order_Commission"],5), 'Order_Profit' => number_format($row["Order_Profit"], 2,".",""), 'Order_Comment' => $row['Order_Comment'], 'Order_MagicNumber' => $row['Order_MagicNumber'], 'Cal' => '<span style="color:green;">'.number_format($actloss, 2,".","").' %</span>', 'Tot' => $tot, 'Datet' => date('d-M-Y h:i:s',strtotime($row["DateTime"])), 'Datet1' => date('d-M-Y H:i:s',strtotime($row["DateTime"])), 'Order_ClosePrice1' => round($row["Order_ClosePrice"],5) ));
         }

    }
   }else{
    if($actloss=="INF" || $actloss==INF || $actloss==null ){
       array_push($arr, array('Broker_Name' => $row['Broker_Name'],'Account_Number' => $row['Account_Number'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Order_Ticket' => $row['Order_Ticket'], 'Order_Symbol' => $row['Order_Symbol'], 'Order_Type' => $row['Order_Type'], 'Order_Lots' => number_format($row["Order_Lots"], 2,".",""), 'Order_StopLoss' => round($row["Order_StopLoss"],5), 'Order_TakeProfit' => round($row["Order_TakeProfit"],5), 'Order_Expiration' => $row['Order_Expiration'], 'Order_OpenPrice' => round($row["Order_OpenPrice"],5), 'Order_OpenTime' => $row['Order_OpenTime'], 'Order_ClosePrice' => round($row["Order_ClosePrice"],5)."<span style='display:none;' id='cps".$row["Order_Ticket"]."'>".$row["cps"]."</span>", 'Order_CloseTime' => $row['Order_CloseTime'], 'Order_Swap' => round($row["Order_Swap"],5), 'Order_Commission' => round($row["Order_Commission"],5), 'Order_Profit' => number_format($row["Order_Profit"], 2,".",""), 'Order_Comment' => $row['Order_Comment'], 'Order_MagicNumber' => $row['Order_MagicNumber'], 'Cal' => '<span style="color:#0d4257;">NA</span>', 'Tot' => $tot, 'Datet' => date('d-M-Y h:i:s',strtotime($row["DateTime"])), 'Datet1' => date('d-M-Y H:i:s',strtotime($row["DateTime"])), 'Order_ClosePrice1' => round($row["Order_ClosePrice"],5) ));
    }else{
        

         if(round($actloss, 5)== "0" || round($actloss, 5)== "-0" || round($actloss, 5)== "+0" ){
            array_push($arr, array('Broker_Name' => $row['Broker_Name'],'Account_Number' => $row['Account_Number'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Order_Ticket' => $row['Order_Ticket'], 'Order_Symbol' => $row['Order_Symbol'], 'Order_Type' => $row['Order_Type'], 'Order_Lots' => number_format($row["Order_Lots"], 2,".",""), 'Order_StopLoss' => round($row["Order_StopLoss"],5), 'Order_TakeProfit' => round($row["Order_TakeProfit"],5), 'Order_Expiration' => $row['Order_Expiration'], 'Order_OpenPrice' => round($row["Order_OpenPrice"],5), 'Order_OpenTime' => $row['Order_OpenTime'], 'Order_ClosePrice' => round($row["Order_ClosePrice"],5)."<span id='cps".$row["Order_Ticket"]."'>".$row["cps"]."</span>", 'Order_CloseTime' => $row['Order_CloseTime'], 'Order_Swap' => round($row["Order_Swap"],5), 'Order_Commission' => round($row["Order_Commission"],5), 'Order_Profit' => number_format($row["Order_Profit"], 2,".",""), 'Order_Comment' => $row['Order_Comment'], 'Order_MagicNumber' => $row['Order_MagicNumber'], 'Cal' => '<span style="color:#0d4257;">'.number_format($actloss, 2,".","").' %</span>', 'Tot' => $tot, 'Datet' => date('d-M-Y h:i:s',strtotime($row["DateTime"])), 'Datet1' => date('d-M-Y H:i:s',strtotime($row["DateTime"])), 'Order_ClosePrice1' => round($row["Order_ClosePrice"],5) ));
         }else{
            array_push($arr, array('Broker_Name' => $row['Broker_Name'],'Account_Number' => $row['Account_Number'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Order_Ticket' => $row['Order_Ticket'], 'Order_Symbol' => $row['Order_Symbol'], 'Order_Type' => $row['Order_Type'], 'Order_Lots' => number_format($row["Order_Lots"], 2,".",""), 'Order_StopLoss' => round($row["Order_StopLoss"],5), 'Order_TakeProfit' => round($row["Order_TakeProfit"],5), 'Order_Expiration' => $row['Order_Expiration'], 'Order_OpenPrice' => round($row["Order_OpenPrice"],5), 'Order_OpenTime' => $row['Order_OpenTime'], 'Order_ClosePrice' => round($row["Order_ClosePrice"],5)."<span style='display:none;' id='cps".$row["Order_Ticket"]."'>".$row["cps"]."</span>", 'Order_CloseTime' => $row['Order_CloseTime'], 'Order_Swap' => round($row["Order_Swap"],5), 'Order_Commission' => round($row["Order_Commission"],5), 'Order_Profit' => number_format($row["Order_Profit"], 2,".",""), 'Order_Comment' => $row['Order_Comment'], 'Order_MagicNumber' => $row['Order_MagicNumber'], 'Cal' => '<span style="color:red;">'.number_format($actloss, 2,".","").' %</span>', 'Tot' => $tot, 'Datet' => date('d-M-Y h:i:s',strtotime($row["DateTime"])), 'Datet1' => date('d-M-Y H:i:s',strtotime($row["DateTime"])), 'Order_ClosePrice1' => round($row["Order_ClosePrice"],5) ));

         }

    }
   }


        

        // array_push($arr, array('Broker_Name' => $row['Broker_Name'],'Account_Number' => $row['Account_Number'], 'Account_Balance' => round($row["Account_Balance"], 2), 'Order_Ticket' => $row['Order_Ticket'], 'Order_Symbol' => $row['Order_Symbol'], 'Order_Type' => $row['Order_Type'], 'Order_Lots' => $row['Order_Lots'], 'Order_StopLoss' => $row['Order_StopLoss'], 'Order_TakeProfit' => $row['Order_TakeProfit'], 'Order_Expiration' => $row['Order_Expiration'], 'Order_OpenPrice' => $row['Order_OpenPrice'], 'Order_OpenTime' => $row['Order_OpenTime'], 'Order_ClosePrice' => $row['Order_ClosePrice'], 'Order_CloseTime' => $row['Order_CloseTime'], 'Order_Swap' => $row['Order_Swap'], 'Order_Commission' => $row['Order_Commission'], 'Order_Profit' => $row['Order_Profit'], 'Order_Comment' => $row['Order_Comment'], 'Order_MagicNumber' => $row['Order_MagicNumber'], 'Cal' => '<span style="color:red;">'.round($actloss, 5).'</span>', 'Tot' => $tot ));
   }

   echo json_encode($arr);

?>