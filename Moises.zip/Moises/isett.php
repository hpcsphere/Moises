<?php
	
 date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)

require_once('config.php');

  $time = filter_input(INPUT_POST, 'time');
  

    $sql = "UPDATE `setting` SET `Time`='".$time."' ";
    $result1=$con->query($sql); 
    echo 1;


    
?>