<!DOCTYPE html>
<html lang="en">
<head>
   <title>MT4 Account Data - Live Monitoring</title>
  <meta charset="utf-8">
 <link rel="icon" type="image/x-icon" href="logo.png" />
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  
  
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script src="js/dataTables.bootstrap4.min.js"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.27.0/moment.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-csv/0.71/jquery.csv-0.71.min.js"></script>
    <script src="js/moment.js"></script>
</head>

<style>
  .loginform
{
    margin-top: 100px;
    background: white;
    /* padding: 31px 42px 1px; */
    padding-left: 53px;
    padding-top: 15px;
    padding-bottom: 15px;
    padding-right: 53px;
    border-radius: 10px;
    width: 45%;
    /* height: 302px; */
    position: relative;
    left: 28%;
    box-shadow: 5px 10px 18px #888888;
    /*color: #2ab4ec;*/
}
.button{
  background-color:#2ab4ec;
  color: white;
  padding:8px;
  border-radius: 4px;
  box-shadow: none;
  border: none;
}
.button:hover {
  background-color: #198dbc;
  color: white;
}

@media (max-width: 500px) and (min-width: 0px){
    .loginform{
      left: 0px ! important;
      width: 100% ! important;
    }
    .button{
      padding:10px;
    }
  }

</style>

<body>
 <header style=" height: 60px;
    padding: 8px;
   
    z-index: 9999;
    width: 100%;
    background-color: #fff;
      -webkit-box-shadow: 0 1px 2px rgb(0 0 0 / 30%);
    box-shadow: 1px 2px 13px rgb(0 0 0 / 30%);
    text-align: center;
    padding-top: 11px;
    font-size: 25px;
     ">MT4 Account Data - Live Monitoring







   </header> 


<div class="container">
  <div class="loginform">
    <center><h2><b>Login</b></h2></center><br>
    <form class="form-horizontal" id="myform" >
    <div class="form-group">
      <label  for="email">Username</label><br>
      <div >
        <input type="name" class="form-control" id="name" placeholder="Enter username" value="<?php echo $_GET['user'] ?>"  required>
      </div>
    </div>
   
    <div class="form-group">
      <label for="pwd">Password</label><br>
      <div >          
        <input type="password" class="form-control" id="pwd" placeholder="Enter password" value="<?php echo $_GET['pass'] ?>" name="pwd" required>
      </div>
    </div>
    <div class="form-group">        
      <div class="">
        <center><button type="submit" class="button"><i class="fa fa-check"></i>&nbsp;Submit&nbsp;</button></center>
      </div>
      
    </div>
  </form>
</div>

 




<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">MT4 Account Data - Live Monitoring</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        Invalid username and/or password!
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


</div>
<script>

   $("form").submit(function(e){
      e.preventDefault();
      var username = $("#name").val();
      var password = $("#pwd").val();
         

      $.post( "check.php", { username, password})
      .done(function( data ) {
        console.log($.trim(data));
        if($.trim(data)=="2"){
          console.log("0");
          $("#myModal").modal();
        }else if($.trim(data)=="1"){
           window.location.href = 'index.php';          
        }
        else if($.trim(data)=="3"){
          window.location.href = 'index1.php';
          
         
        }
        
      });

    });

</script>
</body>
</html>