<?php session_start();

if(isset($_SESSION['id']) && isset($_SESSION['username'])){
 
}
else{
    
    header("Location: login.php");
}

   require_once('config.php');

   date_default_timezone_set("Asia/Kolkata");

?>
<!DOCTYPE html>
<html>
<head>
 

 <title>MT4 Account Data - Live Monitoring</title>
  <meta charset="utf-8">
 <link rel="icon" type="image/x-icon" href="logo.png" />
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  
  
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script src="js/dataTables.bootstrap4.min.js"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.27.0/moment.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-csv/0.71/jquery.csv-0.71.min.js"></script>
    <script src="js/moment.js"></script>
</head>
<style>

  .btns {

        width: 100px;
    overflow-x: hidden;
    cursor: default ! important;
    background-color: #ccc;
  }

  .btd {
        margin-left: 10px;
            padding: 5px;
  }

  .bord {
        border-left: 1px solid lightgrey;
    padding-left: 10px;
  }


  .logout {
        position: absolute;
    right: 20px;
    top: 20px;
    font-size: 20px;
    cursor: pointer;
    color: red;
  }

  .header {
    height: 60px;
    padding: 8px;
   
    z-index: 9999;
    width: 100%;
    background-color: #fff;
      -webkit-box-shadow: 0 1px 2px rgb(0 0 0 / 30%);
    box-shadow: 1px 2px 13px rgb(0 0 0 / 30%);
    text-align: center;
    padding-top: 11px;
    font-size: 25px;
  }





.switch {
  position: relative;
  display: inline-block;
          width: 54px;
    height: 25px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
      height: 18px;
    width: 18px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}


.mt4 {
      width: 50%;
}

.deletebtn {
      right: 130px !important;
}

.custom-select-sm {
        width: 50px;
  }

  .dataTables_filter>label {
        display: inline-flex;
        position: relative;
    left: 10px;
  }


  .fa-pencil{

        font-size: 15px;
    color: #2db4ec;

  }

  .dataTables_wrapper {
           /* width: 106.8%;*/
           overflow: auto;
  }


  .coldiv {
      border: 1px solid #2ab4ec;
      height: auto;
      width: 100%;
     padding: 10px;
    }

    .r1div {
      display: none;
    }

    .vsb {
      background-color: #2ab4ec !important;
      border : 1px solid #2ab4ec !important;
     
      height: 40px;
      width: 100%;
      text-align: left !important;
      border-radius: 0px !important;
    }

    .vsb:hover {
      opacity: 0.6;
    }


    .picon1 {
      float: right;
      margin-top: 3px;
    }

    .micon {
      float: right;
      margin-top: 3px;
    }

    .dnone {
      display: none !important;
    }

    .righta {
      text-align: right;
    }

</style>
<body>

  
   <?php

   require_once("header.html");

    require_once("sidenavbar.html");


   ?>

    

<br><br>
<div class="container" style="padding-left:0px">

 

  <?php 

  $sql1 = "SELECT * FROM setting WHERE 1";
   $result1=$con->query($sql1);

   $time = "";

   while($row1 = $result1->fetch_assoc()) {
    $time = $row1["Time"];
   }


  ?>


<div class="main">

  <form class="form-inline" style="    position: absolute;
    left: 36%;
    border: 1px solid lightgray;
    padding: 15px;
        padding-top: 30px;
    padding-bottom: 30px;
">


  <div class="form-group">
    <label for="email">Refresh rate for open trades  (ms) &nbsp;&nbsp;</label>
    <input type="text" class="form-control" id="time" value="<?php echo $time; ?>" required>
  </div>&nbsp;&nbsp;&nbsp;
  
  <button type="submit" class="btn btn-success"><i class="fa fa-check"></i>&nbsp;&nbsp;Update</button>
  <span style="    position: absolute;
    bottom: 7px;
    left: 170px;color: green;display: none;" id="msg">Updates Successfully.</span>
</form>
    


  
</div>




  


<script>

$(".sett").addClass("active");


$("form").submit(function(e){
      e.preventDefault();

      var time = $("#time").val();

       $.post( "isett.php", { time })
      .done(function( data ) {

        $('#msg').fadeIn(500).fadeOut(2000);

      });

  });
  



</script>

</body>
</html>

