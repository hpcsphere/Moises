<?php session_start();

if(isset($_SESSION['id']) && isset($_SESSION['username'])){
 
}
else{
    
    header("Location: login.php");
}

   require_once('config.php');

   date_default_timezone_set("Asia/Kolkata");


?>
<!DOCTYPE html>
<html>
<head>
 

 <title>MT4 Account Data - Live Monitoring</title>
  <meta charset="utf-8">
 <link rel="icon" type="image/x-icon" href="logo.png" />
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  
  
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script src="js/dataTables.bootstrap4.min.js"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.27.0/moment.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-csv/0.71/jquery.csv-0.71.min.js"></script>
    <script src="js/moment.js"></script>
</head>
<style>

  .btns {

        width: 100px;
    overflow-x: hidden;
    cursor: default ! important;
    background-color: #ccc;
  }

  .btd {
        margin-left: 10px;
            padding: 5px;
  }

  .bord {
        border-left: 1px solid lightgrey;
    padding-left: 10px;
  }


  .logout {
        position: absolute;
    right: 20px;
    top: 20px;
    font-size: 20px;
    cursor: pointer;
    color: red;
  }

  .header {
    height: 60px;
    padding: 8px;
   
    z-index: 9999;
    width: 100%;
    background-color: #fff;
      -webkit-box-shadow: 0 1px 2px rgb(0 0 0 / 30%);
    box-shadow: 1px 2px 13px rgb(0 0 0 / 30%);
    text-align: center;
    padding-top: 11px;
    font-size: 25px;
  }

  .mdiv {

    width: 50%;
    border: 1px solid lightgrey;
   /* padding: 15px;*/
    position: relative;
    left: 26%;
        /*padding-left: 0px;
    padding-right: 60px;*/
  }

</style>
<body>

 

   <?php
   require_once("header.html");
    require_once("sidenavbar.html");


   ?>

    

<br><br>
<div class="container">



<div >

<div class="mdiv">

  <center>

    <h4 style="position: relative;
    top: 15px;"><b>Add New Client</b></h4>

  </center><br>

  <hr>

 <form class="form-horizontal" style="  padding: 15px;  padding-right: 60px;
    padding-bottom: 42px;
">
    <div class="form-group">
      <label class="control-label col-sm-4" for="name">Client Name:</label>
      <div class="col-sm-8">
        <input type="text" class="form-control" id="name" placeholder="Enter Client Name" name="name" required>
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-4" for="email">Client Email ID:</label>
      <div class="col-sm-8">
        <input type="email" pattern="^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$" class="form-control" id="email" placeholder="Enter Client Email ID" name="email" autocomplete="off" required >
      </div>
    </div>






    <div class="form-group">
      <label class="control-label col-sm-4" for="pwd">Password:</label>
      <div class="col-sm-8">          
        <input type="text" class="form-control" id="pwd" placeholder="Enter password for the user portal" name="pwd" autocomplete="off" required>
        <!-- <input class="btn btn-success" type='button' value ='Generate' onclick='document.getElementById("pwd").value = Password.generate(16)'> -->
        <button class="btn btn-success" type="button" onclick='document.getElementById("pwd").value = Password.generate(16)' style="position: absolute;
    right: -15px;
    top: 0px;    width: 25px;" ><i class="fa fa-key"></i></button>
      </div>
    </div>

     <div class="form-group">
      <label class="control-label col-sm-4" for="email">Language:</label>
      <div class="col-sm-8">
       
        <select class="form-control" id="lang">

          <option value="EN">English (EN)</option>
          <option value="JP" class="jap" selected>Japanese (JP)</option>
          <option value="IR">Persian (IR)</option>

        </select>
      </div>
    </div>
    
     <div class="form-group mt40">
      <label class="control-label col-sm-4" for="mt4">MT4 Account:</label>
      <div class="col-sm-8">
        <input type="number" class="form-control mt4 " placeholder="Enter MT4 Account Number" name="mt4" required>
        <button class="btn btn-success addbtn" type="button" style="position: absolute;
    right: -15px;
    top: 0px;" ><i class="fa fa-plus"></i></button>
      </div>
    </div>


    
   
    <div class="form-group" style="    position: relative;
    top: 28px;
">        
      <div class="col-sm-offset-4 col-sm-8">
        <button type="submit" class="btn btn-success"><i class="fa fa-check"></i>&nbsp;Add Client</button>&nbsp;&nbsp;
        <button type="button" class="btn btn-success resetbtn" style="margin-left: 6px;">&nbsp;Reset</button>&nbsp;&nbsp;
        <button type="button" class="btn btn-success copy " style="float: right;"><i class="fa fa-clipboard"></i>&nbsp;Copy credentials to clipboard</button>
        <span id="msg" style="color: green;    margin-left: 65px;display: none;    position: absolute;
    margin-top: 12px;">Successfully Added.</span>
        <span id="msg1" style="color:green;    margin-left: 65px;display: none;    position: absolute;
    margin-top: 12px;" >Copied to Clipboard!</span>
    <span id="msg2" style="color:red;    margin-left: 65px;display: none;    position: absolute;
    margin-top: 12px;" >Kindly enter credentials!</span>
      </div>
    </div>
  </form>

  <hr style="    position: relative;
    bottom: 78px;">

</div>


</div>

</div>


<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">MT4 Account Data - Live Monitoring</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        Email ID is already present in database.
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>




<div class="modal" id="myModal1">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">MT4 Account Data - Live Monitoring</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        This MT4 account number is already present in database.
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>








<?php

      $sql = "SELECT MT4_Account FROM `login` WHERE Username !='admin' ";
       $result=$con->query($sql);
      $mt4a = "";

      while($row = $result->fetch_assoc()) {
        $mt4a .= $row["MT4_Account"];
     }



  ?>



<script>

 var str1 = "<?php echo $mt4a; ?>";
var str2 = "";

  

 


$(".adds").addClass("active");
  

  var mt4 = 0;

$("body").delegate(".addbtn", "click", function(){

if($(".mt4"+mt4).children("div").children("input").hasClass("notv")){

  $("#myModal1").modal();

}else{


if($(".mt4"+mt4).children("div").children("input").val()=="" || $(".mt4"+mt4).children("div").children("input").val()==null ){
  $(".mt4"+mt4).children("div").children("input").css("border", "1px solid orange");
}else{

$(".mt4"+mt4).children("div").children("input").css("border", "1px solid #ced4da");


var mt41 = mt4+1




$(".mt4"+mt4).children("div").children("button").remove();




  $(".mt4"+mt4).after('<div class="form-group mt4'+mt41+' "><label class="control-label col-sm-4" for="mt4">MT4 Account:</label><div class="col-sm-8">        <input type="number" class="form-control mt4" placeholder="Enter MT4 Account Number" name="mt4"> <button class="btn btn-success addbtn" type="button" style="position: absolute; right: -15px; top: 0px;" ><i class="fa fa-plus"></i></button></div></div>');

  mt4 = mt4+1;



  }



}


});






var Password = {
 
  _pattern : /[a-zA-Z0-9_\-\+\.]/,
  
  
  _getRandomByte : function()
  {
    // http://caniuse.com/#feat=getrandomvalues
    if(window.crypto && window.crypto.getRandomValues) 
    {
      var result = new Uint8Array(1);
      window.crypto.getRandomValues(result);
      return result[0];
    }
    else if(window.msCrypto && window.msCrypto.getRandomValues) 
    {
      var result = new Uint8Array(1);
      window.msCrypto.getRandomValues(result);
      return result[0];
    }
    else
    {
      return Math.floor(Math.random() * 256);
    }
  },
  
  generate : function(length)
  {
    return Array.apply(null, {'length': length})
      .map(function()
      {
        var result;
        while(true) 
        {
          result = String.fromCharCode(this._getRandomByte());
          if(this._pattern.test(result))
          {
            return result;
          }
        }        
      }, this)
      .join('');  
  }    
    
};





$("form").submit(function(e){
      e.preventDefault();
      var name = $("#name").val();
      var username = $("#email").val();
      var pwd = $("#pwd").val();
      var lang = $("#lang").val();


      var flag = 0;

      $(".mt4").each(function(index){

        if($(this).hasClass("notv")){
          flag=1;
        }

      });

      if(flag==1){
        $("#myModal1").modal();
      }else{





      // var mt4 = "";
      // var total = $('.mt4').length-1;
      // $(".mt4").each(function(index){
       
      //   if(total==index){
      //     mt4 +=$(this).val();
      //   }else{
      //     mt4 +=$(this).val()+",";
      //   }
        
      // });


      // str2 = str2.substring(str2.length-1, str2.lastIndexOf(" "));

      var lastChar = str2[str2.length -1];

      if(lastChar==","){
        str2 = str2.substring(str2.length-1, str2.lastIndexOf(" "));
      }

     var mt4 = str2;

     

         

      $.post( "addc.php", { name,username,pwd,mt4,lang })
      .done(function( data ) {

        // if($.trim(data)==2){
          if($.trim(data).indexOf("duplicate") != -1){
          $("#myModal").modal();
        }else{
        
         // $("#msg").fadeIn().fadeOut(2000);
         $('#msg').css('display', 'inline-block').hide().fadeIn().fadeOut(2000);





          $.post( "mail.php", { link:"https://ai-ibl.jp/live-data/login.php",name,username,pwd })
        .done(function( data ) {

         
          
        });



        str1 +=","+mt4;


        console.log("str1", str1);


       }
        
      });



    }



    });

  

  $(".copy").click(function(){

    if($("#email").val()=="" || $("#email").val()==null || $("#pwd").val()=="" || $("#pwd").val()==null ){
      $('#msg2').css('display', 'inline-block').hide().fadeIn().fadeOut(2000);
    }else{

    var user = "Login ID : "+$("#email").val()+" \n";
    var pass = "Password : "+$("#pwd").val()+" \n";
    var link = "Login Link : https://staging.hpcsphere.com/employee/sahil/Moises/login.php"+" \n";

    // var text = link+user+pass;
 

    //  var $temp = $("<input>");
    // $("body").append($temp);
    // $temp.val(text).select();
    // document.execCommand("copy");
    // $temp.remove();


 
    var $temp = $("<textarea>");
  $("body").append($temp);
  var html = link+"<br>"+user+"<br>"+pass;;
  html = html.replace(/<br>/g, "\n"); // or \r\n
 
  $temp.val(html).select();
  document.execCommand("copy");
  $temp.remove();



    $('#msg1').css('display', 'inline-block').hide().fadeIn().fadeOut(2000);
    // $("#msg1").fadeIn().fadeOut(2000);



  }


  })

  $(".resetbtn").click(function(){

    $("#name").val('');
    $("#email").val('');
    $("#pwd").val('');
    $(".mt4").val('');


    $("#lang").html('<option value="EN">English (EN)</option><option value="JP" class="jap" selected>Japanese (JP)</option><option value="IR">Persian (IR)</option>');

  });




   $(document).on("focusout",".mt4",function(){

    var total = $('.mt4').length-1;
    
   
    if($(this).val()=="" || $(this).val()==null){
      $(this).css("border", "1px solid #ced4da");
    }else{
  

    if(str1.indexOf($(this).val()) != -1){
     $("#myModal1").modal();
     // $(this).val("");

     $(this).css("border", "1px solid red");

     $(this).addClass("notv");

    }else{

      $(this).removeClass("notv");

        str2 = "";

        $(".mt4").each(function(index){

          

        var l = $(this).val();

      if(str2.indexOf($(this).val()) != -1 && l.length>0 ){
        $(this).css("border", "1px solid red");
        // str2 = str2.substring(str2.length-1, str2.lastIndexOf(" "));
        str2 = str2;
      }else{

       
        if(l.length==0 ){
           $(this).css("border", "1px solid #ced4da");
          // str2 = str2.substring(str2.length-1, str2.lastIndexOf(" "));

          console.log("str2",str2);

       }else{

        $(this).css("border", "1px solid #ced4da");

        if(total==index){
          str2 +=$(this).val();
        }else{
          str2 +=$(this).val()+",";
        }
       }
        

        



      }

        
      });



  

       }

     }


       // console.log("str2", str2);


});

</script>

</body>
</html>

