<?php session_start();

if(isset($_SESSION['id']) && isset($_SESSION['username'])){
 
}
else{
    
    header("Location: login.php");
}

   require_once('config.php');

   date_default_timezone_set("Asia/Kolkata");



   $sql1 = "SELECT * FROM Open_Trades WHERE 1  group by Account_Number ";
   $result1=$con->query($sql1);

   $accn = [];

   while($row1 = $result1->fetch_assoc()) {

    array_push($accn,$row1["Account_Number"]);

 }

 echo json_encode($accn);



?>