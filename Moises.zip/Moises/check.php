<?php session_start();
include "config.php";
if(isset($_POST['username']) ){
    
    $username =$_POST['username'];
    $password =$_POST['password'];

        $sql="SELECT * FROM login WHERE Username='$username' AND Password='$password' AND Status='0'  ";
        $result=mysqli_query($con,$sql);
        if( mysqli_num_rows($result)==1){
            $row=mysqli_fetch_assoc($result);
            
            if($row["Username"]==$_POST["username"] && $row["Password"]==$_POST["password"])
            {
             
                $_SESSION['id']=$row['Username'];
                $_SESSION['username']=$row['Username'];
                
                if($row['Username']=="admin"){
                    $_SESSION['name']="admin";
                   
                    echo "1";
                    
                }else{
                    $_SESSION['name']="user";
                    echo "3";
                }
                
               

                
            }
            else{
                echo "2";
            }
        }
            else{
                echo "2";

            }
    

}
else{

    exit();
}
?>