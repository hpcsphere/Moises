<?php 

define('DB_HOSTNAME', '127.0.0.1');

	define('DB_USERNAME', 'urak6s3guownx');

	define('DB_PASSWORD', 'cwnmi8fcglgh');

	define('DB_DATABASE', 'dbkbwbntchz5d2');

	// define('DB_HOSTNAME', '127.0.0.1');

	// define('DB_USERNAME', 'root');

	// define('DB_PASSWORD', '');

	// define('DB_DATABASE', 'Trading_New');

	

	// define('DB_HOSTNAME', 'mysql201.phy.lolipop.lan');

	// define('DB_USERNAME', 'LAA0907153');

	// define('DB_PASSWORD', 'GkdrFf5k8NSsESgi');

	// define('DB_DATABASE', 'LAA0907153-livedata');


	$con = mysqli_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD,DB_DATABASE);

	if ($con->connect_error) {
		die("Connection failed: " . $con->connect_error);
	} 


	
	
   if( isset($_GET['Broker_Name']) && isset($_GET['Account_Number']) && isset($_GET['Account_Balance']) && isset($_GET['Order_Ticket']) && isset($_GET['Order_Symbol']) && isset($_GET['Order_Type']) && isset($_GET['Order_Lots']) && isset($_GET['Order_StopLoss']) && isset($_GET['Order_TakeProfit']) && isset($_GET['Order_Expiration']) && isset($_GET['Order_OpenPrice']) && isset($_GET['Order_OpenTime']) && isset($_GET['Order_ClosePrice']) && isset($_GET['Order_CloseTime']) && isset($_GET['Order_Swap'])&& isset($_GET['Order_Commission'])&& isset($_GET['Order_Profit'])&& isset($_GET['Order_Comment']) && isset($_GET['Order_MagicNumber']) ){

   	$result = $con->query("SELECT * FROM Open_Trades WHERE Account_Number='".$_GET['Account_Number']."' and Order_Ticket='".$_GET['Order_Ticket']."' ");

   	if( mysqli_num_rows($result)>0){
   // 		 $sql = "UPDATE `Open_Trades` SET `Broker_Name`='".$_GET['Broker_Name']."', Account_Number='".$_GET['Account_Number']."', Account_Balance='".$_GET['Account_Balance']."',Order_Ticket='".$_GET['Order_Ticket']."', Order_Symbol='".$_GET['Order_Symbol']."', Order_Type='".$_GET['Order_Type']."', Order_Lots='".$_GET['Order_Lots']."', Order_StopLoss='".$_GET['Order_StopLoss']."', Order_TakeProfit='".$_GET['Order_TakeProfit']."', Order_ClosePrice='".$_GET['Order_ClosePrice']."', Order_CloseTime='".$_GET['Order_CloseTime']."', Order_Swap='".$_GET['Order_Swap']."', Order_Commission='".$_GET['Order_Commission']."', Order_Profit='".$_GET['Order_Profit']."', Order_Comment='".$_GET['Order_Comment']."', Order_MagicNumber='".$_GET['Order_MagicNumber']."', Order_Expiration='".$_GET['Order_Expiration']."', Order_OpenPrice='".$_GET['Order_OpenPrice']."', Order_OpenTime='".$_GET['Order_OpenTime']."' WHERE Account_Number='".$_GET['Account_Number']."' and  Order_Ticket='".$_GET['Order_Ticket']."' ";
	  // $result1=$con->query($sql);	


   		// echo 1;


   		 $sql1 = "DELETE FROM `Open_Trades` WHERE Account_Number='".$_GET['Account_Number']."' ";
	  $result11=$con->query($sql1);	


	  

	  $sql = "INSERT INTO `Open_Trades`(`Broker_Name`, `Account_Number`, `Order_Ticket`, `Order_Symbol`, `Order_Type`, `Order_Lots`, `Order_StopLoss`, `Order_TakeProfit`, `Order_Expiration`, `Order_OpenPrice`, `Order_OpenTime`, `Order_ClosePrice`, `Order_CloseTime`, `Order_Swap`, `Order_Commission`, `Order_Profit`, `Order_Comment`, `Order_MagicNumber`, `Account_Balance`  ) VALUES ( '".$_GET['Broker_Name']."', '".$_GET['Account_Number']."', '".$_GET['Order_Ticket']."', '".$_GET['Order_Symbol']."', '".$_GET['Order_Type']."', '".$_GET['Order_Lots']."', '".$_GET['Order_StopLoss']."', '".$_GET['Order_TakeProfit']."', '".$_GET['Order_Expiration']."', '".$_GET['Order_OpenPrice']."', '".$_GET['Order_OpenTime']."', '".$_GET['Order_ClosePrice']."', '".$_GET['Order_CloseTime']."', '".$_GET['Order_Swap']."', '".$_GET['Order_Commission']."', '".$_GET['Order_Profit']."', '".$_GET['Order_Comment']."', '".$_GET['Order_MagicNumber']."', '".$_GET['Account_Balance']."'  )";

			if($con->query($sql))
			  {   

			  	echo 1;
			  }


   	}else{
   		

   		$sql = "INSERT INTO `Open_Trades`(`Broker_Name`, `Account_Number`, `Order_Ticket`, `Order_Symbol`, `Order_Type`, `Order_Lots`, `Order_StopLoss`, `Order_TakeProfit`, `Order_Expiration`, `Order_OpenPrice`, `Order_OpenTime`, `Order_ClosePrice`, `Order_CloseTime`, `Order_Swap`, `Order_Commission`, `Order_Profit`, `Order_Comment`, `Order_MagicNumber`, `Account_Balance`  ) VALUES ( '".$_GET['Broker_Name']."', '".$_GET['Account_Number']."', '".$_GET['Order_Ticket']."', '".$_GET['Order_Symbol']."', '".$_GET['Order_Type']."', '".$_GET['Order_Lots']."', '".$_GET['Order_StopLoss']."', '".$_GET['Order_TakeProfit']."', '".$_GET['Order_Expiration']."', '".$_GET['Order_OpenPrice']."', '".$_GET['Order_OpenTime']."', '".$_GET['Order_ClosePrice']."', '".$_GET['Order_CloseTime']."', '".$_GET['Order_Swap']."', '".$_GET['Order_Commission']."', '".$_GET['Order_Profit']."', '".$_GET['Order_Comment']."', '".$_GET['Order_MagicNumber']."', '".$_GET['Account_Balance']."'  )";

			if($con->query($sql))
			  {   

			  	echo 1;
			  }
   		
   	}

   }else{
  
   	echo -1;
   }




?>