<?php

	require_once('config.php');
	
	if(isset($_POST['name'])){

		$sql4="UPDATE  `login` SET `Name`='".$_POST['name']."' WHERE `SN`='".$_POST['sl']."'";
        $con->query($sql4);

	}else if(isset($_POST['pass'])){

		$sql4="UPDATE  `login` SET `Password`='".$_POST['pass']."' WHERE `SN`='".$_POST['sl']."'";
        $con->query($sql4);

	}else if(isset($_POST['status'])){

		$sql4="UPDATE  `login` SET `Status`='".$_POST['status']."' WHERE `SN`='".$_POST['sl']."'";
        $con->query($sql4);

	}else if(isset($_POST['mt4'])){

		$sql4="UPDATE  `login` SET `MT4_Account`='".$_POST['mt4']."' WHERE `SN`='".$_POST['sl']."'";
        $con->query($sql4);

	}

	else if(isset($_POST['lang'])){

		$sql4="UPDATE  `login` SET `Language`='".$_POST['lang']."' WHERE `SN`='".$_POST['sl']."'";
        $con->query($sql4);

	}



	else if(isset($_POST['sn'])){

		$sql4="DELETE FROM `login` WHERE `SN`='".$_POST['sn']."'";
        $con->query($sql4);


		$array = explode(',', $_POST['mta']);

		for ($i=0; $i < sizeof($array); $i++) { 
			
			$sql5="DELETE FROM `Live_Trading_Data` WHERE `Account_Number`='".$array[$i]."'";
        	$con->query($sql5);
		}


	}



?>