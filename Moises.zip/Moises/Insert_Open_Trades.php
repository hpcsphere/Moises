<?php 

	// define('DB_HOSTNAME', '127.0.0.1');

	// define('DB_USERNAME', 'urak6s3guownx');

	// define('DB_PASSWORD', 'cwnmi8fcglgh');

	// define('DB_DATABASE', 'dbkbwbntchz5d2');

	

	

	

	// $con = mysqli_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD,DB_DATABASE);

	// if ($con->connect_error) {
	// 	die("Connection failed: " . $con->connect_error);
	// } 

	
	require_once('config.php');


	 date_default_timezone_set("Asia/Kolkata");
	
	
	$date = date('Y-m-d H:i:s');
  



$strRequest = file_get_contents('php://input');

	

	


	$strRequest = str_replace("'","\"",$strRequest);

 $Request = json_decode($strRequest, true);
 $fp = fopen('txt1.txt', 'w');
fwrite($fp,  $strRequest );

fclose($fp);


$sql1 = "DELETE FROM `Open_Trades` WHERE Account_Number='".$Request[0]["Account_Number"]."' ";
	  // $result11=$con->query($sql1);	

if($con->query($sql1)){   

	foreach($Request as $item) { 
	 

		$cps = 0;

		 $sql11 = "SELECT * FROM Open_Trades WHERE Order_Ticket='".$item['Order_Ticket']."' ";
		 $result11=$con->query($sql11);
		 while($row11 = $result11->fetch_assoc()) {
		 	if($item['Order_Ticket']>$row11["Order_Ticket"]){
		 		$cps = 1;
		 	}elseif($item['Order_Ticket']<$row11["Order_Ticket"]){
		 		$cps = 2;
		 	}else{
		 		$cps = 0;
		 	}


		 }
		  

		  

	   		$sql = "INSERT INTO `Open_Trades`(`Broker_Name`, `Account_Number`, `Order_Ticket`, `Order_Symbol`, `Order_Type`, `Order_Lots`, `Order_StopLoss`, `Order_TakeProfit`, `Order_Expiration`, `Order_OpenPrice`, `Order_OpenTime`, `Order_ClosePrice`, `Order_CloseTime`, `Order_Swap`, `Order_Commission`, `Order_Profit`, `Order_Comment`, `Order_MagicNumber`, `Account_Balance`,`DateTime`, `UnrealisedProfitPercentage`, `cps`  ) VALUES ( '".$item['Broker_Name']."', '".$item['Account_Number']."', '".$item['Order_Ticket']."', '".$item['Order_Symbol']."', '".$item['Order_Type']."', '".$item['Order_Lots']."', '".$item['Order_StopLoss']."', '".$item['Order_TakeProfit']."', '".$item['Order_Expiration']."', '".$item['Order_OpenPrice']."', '".$item['Order_OpenTime']."', '".$item['Order_ClosePrice']."', '".$item['Order_CloseTime']."', '".$item['Order_Swap']."', '".$item['Order_Commission']."', '".$item['Order_Profit']."', '".$item['Order_Comment']."', '".$item['Order_MagicNumber']."', '".$item['Account_Balance']."','".$date."', '".$item['UnrealisedProfitPercentage']."' , '".$cps."' )";

				if($con->query($sql))
				  {   

				  	echo 1;
				  }
	   		




	}


}




?>