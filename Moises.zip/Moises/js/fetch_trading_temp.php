 <?php
 require_once('config.php');

    $i = 1;

   $sql = "SELECT * FROM Live_Trading_Data WHERE 1";
   $result=$con->query($sql);
   $arr = array();
   while($row = $result->fetch_assoc()) {

      array_push($arr, array('Account_Name' => $row['Account_Name'],'Account_Number' => $row['Account_Number'], 'Account_Equity' => $row['Account_Equity'], 'Margin_Level' => $row['Margin_Level'], 'Highest_Position_Symbol' => $row['Highest_Position_Symbol'], 'Highest_Position_Lot_Size' => $row['Highest_Position_Lot_Size'], 'Account_Balance' => $row['Account_Balance'], 'Profit_Per' => $row['Profit_Per'], 'Profit_Amt' => $row['Profit_Amt'] ));



   }
   echo json_encode($arr);

?>