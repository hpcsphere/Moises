<?php session_start();

if(isset($_SESSION['id']) && isset($_SESSION['username'])){
 
}
else{
    
    header("Location: login.php");
}

   require_once('config.php');

   date_default_timezone_set("Asia/Kolkata");

?>
<!DOCTYPE html>
<html>
<head>
 

 <title>MT4 Account Data - Live Monitoring</title>
  <meta charset="utf-8">
 <link rel="icon" type="image/x-icon" href="logo.png" />
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  
  
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script src="js/dataTables.bootstrap4.min.js"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.27.0/moment.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-csv/0.71/jquery.csv-0.71.min.js"></script>
    <script src="js/moment.js"></script>
</head>
<style>

  .btns {

        width: 100px;
    overflow-x: hidden;
    cursor: default ! important;
    background-color: #ccc;
  }

  .btd {
        margin-left: 10px;
            padding: 5px;
  }

  .bord {
        border-left: 1px solid lightgrey;
    padding-left: 10px;
  }


  .logout {
        position: absolute;
    right: 20px;
    top: 20px;
    font-size: 20px;
    cursor: pointer;
    color: red;
  }

  .header {
    height: 60px;
    padding: 8px;
   
    z-index: 9999;
    width: 100%;
    background-color: #fff;
      -webkit-box-shadow: 0 1px 2px rgb(0 0 0 / 30%);
    box-shadow: 1px 2px 13px rgb(0 0 0 / 30%);
    text-align: center;
    padding-top: 11px;
    font-size: 25px;
  }





.switch {
  position: relative;
  display: inline-block;
          width: 54px;
    height: 25px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
      height: 18px;
    width: 18px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}


.mt4 {
      width: 50%;
}

.deletebtn {
      right: 130px !important;
}

.custom-select-sm {
        width: 50px;
  }

</style>
<body>

  <header class="header" style=" 
     ">MT4 Account Data - Live Monitoring


<a href="logout.php"><i class="fa fa-sign-out logout" aria-hidden="true" title="Logout" ></i></a>





   </header> 

   <?php

    require_once("sidenavbar.html");


   ?>

    

<br><br>
<div class="container">

  <!-- <div align="center">
      <div class="form-group" style="display: inline-flex;width: 100%;justify-content: center;">
        <form>
          <label>Symbol:</label>
          <input type="text" name="Symbol" id="symbol" placeholder="Please enter Symbol" style="height: 28px;width: 170px;" required>&nbsp;&nbsp;
          <label>Entry Price:</label>
        <input type="text" name="Entry Price" id="price" placeholder="Please enter Entry Price" style="height: 28px;width: 170px;" required>&nbsp;&nbsp;

         <label>Signal:</label>
       <select id="signal" style="height: 28px;width: 70px;">
        <option class="null">Buy</option>
        <option>Sell</option>
       </select>&nbsp;&nbsp;

          <button class="btn btn-success add"><i class="fa fa-plus"></i>&nbsp;&nbsp;<i class="fa fa-spinner fa-spin" style="font-size: 17px;position: absolute;margin-top: -1px;display:none ;"></i>Add Trading Point</button>
        </form>
      </div>
     
    </div>

     <span style="    font-size: 15px;
    color: green;
    position: absolute;
    left: 42%;
    margin-top: 12px;">

      <?php echo date("d-M-Y"); echo " ";

        $date = new DateTime();
        $timeZone = $date->getTimezone();
        echo $timeZone->getName();



       ?>
       <span id="zone"></span>
     </span> -->

          
 <!--  <table class="table table-bordered" id="table">
    <thead>
  <tr>
    <th><center>Sl.No.</center></th>
    <th>Account Number</th>
    <th>Account Equity</th>
    <th>Margin Level %</th>
    <th>Highest Position Symbol </th>
    <th>highest Position Lot Size</th>
  </tr>
</thead>
<tbody>
 
</tbody>
</table> -->


<div class="main">

  <span style="    position: absolute;
    left: 48%;
    margin-top: 22px;color: green;display: none;" class="upmsg"><i class="fa fa-check"></i>&nbsp;&nbsp;Successfully updated.</span>

  <table class="table table-bordered" id="table">
    <thead>
  <tr>
    <th><center>Sl.No.</center></th>
    <th>Client Name</th>
    <th>Login Email ID</th>
    <th>Password</th>
    <th>Linked MT4 Accounts</th>
    <th>Total Deposit</th>
    <th>Total Equity</th>
    <th>Total Profit</th>
    <th>Total Withdraw</th>
    <th>Enable/Disable Client</th>
    <th>Delete</th>
   
  </tr>
</thead>
<tbody>
 <?php
 require_once('config.php');

    $i1 = 1;

   $sql = "SELECT * FROM login WHERE Username !='admin' ";
   $result=$con->query($sql);
   while($row = $result->fetch_assoc()) {



   echo "<tr class='tr' id='".$row["SN"]."''>";
  
    echo "<td>".$i1."</td>";
    echo "<td contenteditable class='name'>".$row["Name"]."</td>";
    echo "<td class='email'>".$row["Username"]."</td>";
    echo "<td contenteditable class='pass' >".$row["Password"]."</td>";
    echo "<td><span style='display:none;' class='mta'>".$row["MT4_Account"]."</span><button class='btn btn-success mt4btn'><i class='fa fa-eye'></i>&nbsp;MT4 Accounts</button></td>";

    $array = explode(',', $row["MT4_Account"]);

    
    $dep = 0;
    $eq = 0;
    $pr = 0;
    $wi = 0;


    for ($i=0; $i < sizeof($array); $i++) { 
      


       $sql1 = "SELECT * FROM `Live_Trading_Data` WHERE Account_Number='".$array[$i]."' ";
       $result1=$con->query($sql1);
       while($row1 = $result1->fetch_assoc()) {
        $dep = $row1["Deposit"]+$dep;
        $eq = $row1["Account_Equity"]+$eq;
        $pr = $row1["Profit_Amt"]+$pr;
        $wi = $row1["Withdraw"]+$wi;
       }


    }

    echo "<td>".$dep."</td>";
    echo "<td>".$eq."</td>";


    if($pr>=0){
       echo "<td>".$pr."</td>";
    }else{ 
       echo "<td style='background: #f59a9a;'>".$pr."</td>";
    }

   
    echo "<td>".$wi."</td>";


    if($row["Status"]==0){
      echo '<td><label class="switch">
  <input type="checkbox" checked>
  <span class="slider round"></span>
</label></td>';
    }else{
      echo '<td><label class="switch">
  <input type="checkbox" >
  <span class="slider round"></span>
</label></td>';
    }

    
   

   echo '<td><button class="btn btn-danger delbtn"><i class="fa fa-trash"></i>&nbsp;Delete</button></td>';

    
    echo "</tr>";

    $i1++;

   }

  ?>

</tbody>
</table>









</div>

</div>




<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">MT4 Account Data - Live Monitoring</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">

        <div class="ne">
                  
        </div>
        
        <form class="form-horizontal form" style="position: relative;
    left: 91px;"></form>



        <button class="btn btn-success addbtn" type="button" style="    position: relative;
    left: 100px;
    margin-bottom: 10px;    width: 277px;" ><i class="fa fa-plus"></i>&nbsp; Add Another MT4 Account</button>


      </div>

      <!-- Modal footer -->
      <div class="modal-footer">

        <center class="msgs" style="color:green;position: absolute;
    left: 45%;display: none;">Account Saved!</center>

        <button type="button" class="btn btn-primary" data-dismiss="modal" style="    position: relative;
    right: 98px;">Done</button>
      </div>

    </div>
  </div>
</div>










<!-- The Modal -->
<div class="modal" id="delModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">MT4 Account Data - Live Monitoring</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">

      
        <p>Do you really want to delete this client?</p>


      </div>

      <!-- Modal footer -->
      <div class="modal-footer">

        <center class="delmsg" style="color:red;position: absolute;
    left: 45%;display: none;">Client Deleted!</center>

        <button type="button" class="btn btn-success yesbtn">Yes</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>




  


<script>


  


  var table = $('#table').DataTable({
        "iDisplayLength": 100,
        
        "language": {
          "search": "Search"
        }

  });
  

 


$(".users").addClass("active");



$(document).on("focusout",".name",function(){

  var name = $(this).text();
  var sl = $(this).parent("tr").attr("id");

   $.post( "update.php", { name,sl })
      .done(function( data ) {

        $(".upmsg").fadeIn().fadeOut(3000);
        
      });


});


$(document).on("focusout",".pass",function(){

  var pass = $(this).text();
  var sl = $(this).parent("tr").attr("id");

  $.post( "update.php", { pass,sl })
      .done(function( data ) {

        $(".upmsg").fadeIn().fadeOut(3000);
        
      });

});


$(".slider").click(function(){

  var sl = $(this).parent("label").parent("td").parent("tr").attr("id");

  if($(this).siblings("input").is(':checked'))
  {
   
    var status = 1;
    $.post( "update.php", { status,sl })
      .done(function( data ) {

        
        
      });
  }else
  {
  var status = 0;
   $.post( "update.php", { status,sl })
      .done(function( data ) {

        
        
      });
  }



});



var mt4 = 0;
var thi = "";
var sl = "";


$(".mt4btn").click(function(){

mt4 = 0;

sl = $(this).parent("td").parent("tr").attr("id");

thi = this;

  var acc = "["+$(this).siblings("span").text()+"]";

  var parse = JSON.parse(acc);

  var html = "";


  for (var i = 0; i < parse.length; i++) {
    

    if(i==parse.length-1){
      // html += '<div class="form-group mt4'+i+'" data="mt4'+i+'" style="width: 90%;"><label class="control-label col-sm-3" for="mt4">MT4 Account:</label> <div class="col-sm-9"><input type="text" value="'+parse[i]+'" class="form-control mt4 " placeholder="Enter MT4 Account" name="mt4" required disabled ><button class="btn btn-success addbtn" type="button" style="position: absolute; right: -15px;top: 0px;" ><i class="fa fa-plus"></i></button><button class="btn btn-danger deletebtn" type="button" style="position: absolute; right: -45px;top: 0px;" ><i class="fa fa-trash"></i></button></div></div>';


       html += '<div class="form-group mt4'+i+'" data="mt4'+i+'" style="width: 90%;"><label class="control-label col-sm-3" for="mt4">MT4 Account:</label> <div class="col-sm-9"><input type="number" value="'+parse[i]+'" class="form-control mt4 " placeholder="Enter MT4 Account" name="mt4" required disabled><button class="btn btn-danger deletebtn" type="button" style="position: absolute; right: -15px;top: 0px;" ><i class="fa fa-trash"></i></button></div></div>';

    }else{
      html += '<div class="form-group mt4'+i+'" data="mt4'+i+'" style="width: 90%;"><label class="control-label col-sm-3" for="mt4">MT4 Account:</label> <div class="col-sm-9"><input type="number" value="'+parse[i]+'" class="form-control mt4 " placeholder="Enter MT4 Account" name="mt4" required disabled><button class="btn btn-danger deletebtn" type="button" style="position: absolute; right: -15px;top: 0px;" ><i class="fa fa-trash"></i></button></div></div>';
    }

    
    mt4 = mt4+1;

  }

  mt4 = mt4-1;



  $(".form").html(html);



  var name = $(this).parent("td").siblings(".name").text();
  var email = $(this).parent("td").siblings(".email").text();

  
  $(".ne").html("<p><b>"+name+" | "+email+"</b></p>");


    $("#myModal").modal();


});







$("body").delegate(".addbtn", "click", function(){


var mt41 = mt4+1




$(".mt4"+mt4).children("div").children(".addbtn").remove();
$(".mt4"+mt4).children("div").children(".deletebtn").css("right", "-15px" );


  // $(".mt4"+mt4).after('<div class="form-group mt4'+mt41+'" data="mt4'+mt41+'" style="width: 90%;"><label class="control-label col-sm-3" for="mt4">MT4 Account:</label> <div class="col-sm-9"><input type="text" class="form-control mt4 " placeholder="Enter MT4 Account" name="mt4" required ><button class="btn btn-success addbtn" type="button" style="position: absolute; right: -15px;top: 0px;" ><i class="fa fa-plus"></i></button><button class="btn btn-danger deletebtn" type="button" style="position: absolute; right: -45px;top: 0px;" ><i class="fa fa-trash"></i></button></div></div>');


   $(".mt4"+mt4).after('<div class="form-group mt4'+mt41+'" data="mt4'+mt41+'" style="width: 90%;"><label class="control-label col-sm-3" for="mt4">MT4 Account:</label> <div class="col-sm-9"><input type="number" class="form-control mt4 " placeholder="Enter MT4 Account" name="mt4" required ><button class="btn btn-danger deletebtn" type="button" style="position: absolute; right: -15px;top: 0px;" ><i class="fa fa-trash"></i></button></div></div>');


  mt4 = mt4+1;

  

});





$(document).on("focusout",".mt4",function(){

    var mt4 = "";
    var total = $('.mt4').length-1;

    var txt = $(thi).siblings("span").text();
    console.log("txt", txt);

    if(txt.indexOf($(this).val()) != -1){
     
    }else{
      
   

   $(".mt4").each(function(index){

    var l = $(this).val();

    

       // if($(this).val()=="" || $(this).val()==null ){
        if(l.length==0 ){
          mt4 = mt4.substring(mt4.length-1, mt4.lastIndexOf(" "));

       }else{
        if(total==index){
          mt4 +=$(this).val();
        }else{
          mt4 +=$(this).val()+",";
        }
       }
        
        
      });


   $(thi).siblings("span").text(mt4);

   
   $.post( "update.php", { mt4,sl })
      .done(function( data ) {

        $(".msgs").fadeIn().fadeOut(2000);
        
      });


       }


});


$("body").delegate(".deletebtn", "click", function(){

  if($(this).siblings("button").hasClass("addbtn")){
    // console.log("class", $(this).parent("div").parent("div").attr("data") );
  }else{
    // $(this).parent("div").parent("div").remove();



    $(this).parent("div").parent("div").css("display", "none");
    $(this).siblings("input").removeClass("mt4");

  }


 var mt4 = "";
    var total = $('.mt4').length-1;

   $(".mt4").each(function(index){
       if($(this).val()=="" || $(this).val()==null ){

       }else{
        if(total==index){
          mt4 +=$(this).val();
        }else{
          mt4 +=$(this).val()+",";
        }
       }
        
        
      });


   $(thi).siblings("span").text(mt4);

   $.post( "update.php", { mt4,sl })
      .done(function( data ) {

        
        
      });


});


var sn = "";
var del = "";
var mta = "";


$(".delbtn").click(function(){

  del = this;

   sn = $(this).parent("td").parent("tr").attr("id");

   mta = $(this).parent("td").siblings("td").children(".mta").text();



  $("#delModal").modal();


});


$(".yesbtn").click(function(){


  




    $.post( "update.php", { sn,mta })
      .done(function( data ) {

        $(".delmsg").fadeIn().fadeOut(2000);
        $(del).parent("td").parent("tr").remove();
        ser();
        $("#delModal").modal("toggle");
        
      });


});



function ser(){
  var i = 1;
  var sizeofrows=(table.rows().data()).length;
 
  $(".tr").each(function(){


   $( this ).find( "td:eq(0)" ).text(i)

    i++;
    
  });
}


</script>

</body>
</html>

