<?php
	
 date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)

require_once('config.php');

  $name = filter_input(INPUT_POST, 'name');
  $username = filter_input(INPUT_POST, 'username');

  $pwd =filter_input(INPUT_POST, 'pwd'); 

  $mt4 =filter_input(INPUT_POST, 'mt4'); 

  $lang =filter_input(INPUT_POST, 'lang'); 

 $sql1="SELECT * FROM login WHERE Username='$username' ";
  $result1=mysqli_query($con,$sql1);

  if( mysqli_num_rows($result1)==1){

    echo "2";

  }else{

    $sql = "INSERT INTO `login`(`Username`, `Password`, `Name`, `MT4_Account`, `Language` ) VALUES ('".$username."','".$pwd."','".$name."','".$mt4."','".$lang."' ) ";
    $result=$con->query($sql);

    echo $sql;

  }

    
?>