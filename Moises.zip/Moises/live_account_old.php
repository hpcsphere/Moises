<?php 

// define('DB_HOSTNAME', '127.0.0.1');

// 	define('DB_USERNAME', 'urak6s3guownx');

// 	define('DB_PASSWORD', 'cwnmi8fcglgh');

// 	define('DB_DATABASE', 'dbgpmuno4twfef');

	// define('DB_HOSTNAME', '127.0.0.1');

	// define('DB_USERNAME', 'root');

	// define('DB_PASSWORD', '');

	// define('DB_DATABASE', 'Trading');

	

	define('DB_HOSTNAME', 'mysql201.phy.lolipop.lan');

	define('DB_USERNAME', 'LAA0907153');

	define('DB_PASSWORD', 'GkdrFf5k8NSsESgi');

	define('DB_DATABASE', 'LAA0907153-livedata');


	$con = mysqli_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD,DB_DATABASE);

	if ($con->connect_error) {
		die("Connection failed: " . $con->connect_error);
	} 


	
	
   if( isset($_GET['Account_Number']) && isset($_GET['Account_Equity']) && isset($_GET['Margin_Level']) && isset($_GET['Highest_Position_Symbol']) && isset($_GET['Highest_Position_Lot_Size']) && isset($_GET['Account_Name']) && isset($_GET['Account_Balance']) && isset($_GET['Profit_Per']) && isset($_GET['Profit_Amt']) ){

   	$result = $con->query("SELECT * FROM Live_Trading_Data WHERE Account_Number='".$_GET['Account_Number']."' ");

   	if( mysqli_num_rows($result)>0){
   		 $sql = "UPDATE `Live_Trading_Data` SET `Account_Equity`='".$_GET['Account_Equity']."', Margin_Level='".$_GET['Margin_Level']."',Highest_Position_Symbol='".$_GET['Highest_Position_Symbol']."', Highest_Position_Lot_Size='".$_GET['Highest_Position_Lot_Size']."', Account_Name='".$_GET['Account_Name']."', Account_Balance='".$_GET['Account_Balance']."', Profit_Per='".$_GET['Profit_Per']."', Profit_Amt='".$_GET['Profit_Amt']."' WHERE Account_Number='".$_GET['Account_Number']."' ";
	  $result1=$con->query($sql);	
	  echo 1;

   	}else{
   		

   		$sql = "INSERT INTO `Live_Trading_Data`(`Account_Number`, `Account_Equity`, `Margin_Level`, `Highest_Position_Symbol`, `Highest_Position_Lot_Size`, `Account_Name`, `Account_Balance`, `Profit_Per`, `Profit_Amt` ) VALUES ('".$_GET['Account_Number']."', '".$_GET['Account_Equity']."', '".$_GET['Margin_Level']."', '".$_GET['Highest_Position_Symbol']."', '".$_GET['Highest_Position_Lot_Size']."', '".$_GET['Account_Name']."', '".$_GET['Account_Balance']."', '".$_GET['Profit_Per']."', '".$_GET['Profit_Amt']."' )";

			if($con->query($sql))
			  {   

			  	echo 1;
			  }
   		
   	}

   }else{
  
   	echo -1;
   }




?>