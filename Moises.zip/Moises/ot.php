<?php session_start();

if(isset($_SESSION['id']) && isset($_SESSION['username'])){
 
}
else{
    
    header("Location: login.php");
}

   require_once('config.php');

   date_default_timezone_set("Asia/Kolkata");

?>
<!DOCTYPE html>
<html>
<head>
 

 <title>MT4 Account Data - Live Monitoring</title>
  <meta charset="utf-8">
 <link rel="icon" type="image/x-icon" href="logo.png" />
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  
  
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script src="js/dataTables.bootstrap4.min.js"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.27.0/moment.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-csv/0.71/jquery.csv-0.71.min.js"></script>
    <script src="js/moment.js"></script>



    
  

</head>
<style>

  .btns {

        width: 100px;
    overflow-x: hidden;
    cursor: default ! important;
    background-color: #ccc;
  }

  .btd {
        margin-left: 10px;
            padding: 5px;
  }

  .bord {
        border-left: 1px solid lightgrey;
    padding-left: 10px;
  }


  .logout {
        position: absolute;
    right: 20px;
    top: 20px;
    font-size: 20px;
    cursor: pointer;
    color: red;
  }

  .header {
    height: 60px;
    padding: 8px;
   
    z-index: 9999;
    width: 100%;
    background-color: #fff;
      -webkit-box-shadow: 0 1px 2px rgb(0 0 0 / 30%);
    box-shadow: 1px 2px 13px rgb(0 0 0 / 30%);
    text-align: center;
    padding-top: 11px;
    font-size: 25px;
  }





.switch {
  position: relative;
  display: inline-block;
          width: 54px;
    height: 25px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
      height: 18px;
    width: 18px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}


.mt4 {
      width: 50%;
}

.deletebtn {
      right: 130px !important;
}

.custom-select-sm {
        width: 50px;
  }

  .dataTables_filter>label {
        display: inline-flex;
        position: relative;
    left: 10px;
  }


  .fa-pencil{

        font-size: 15px;
    color: #2db4ec;

  }

  .dataTables_wrapper {
           /* width: 106.8%;*/
           overflow: auto;
  }


  .coldiv {
      border: 1px solid #2ab4ec;
      height: auto;
      width: 100%;
     padding: 10px;
    }

    .r1div {
      display: none;
    }

    .vsb {
      background-color: #2ab4ec;
      border : 1px solid #2ab4ec !important;
     
      height: 40px;
      width: 100%;
      text-align: left !important;
      border-radius: 0px !important;
    }

    .vsb:hover {
          background-color: #2084bd;
    }


    .picon1 {
      float: right;
      margin-top: 3px;
      margin-top: -17px;
    }

    .micon {
      float: right;
      margin-top: 3px;
      margin-top: -17px;
    }

    .dnone {
      display: none !important;
    }

    .righta {
      text-align: right;
    }

    .bns {
      width: 140px;
      border-right: 1px solid white;
    }

    .acs{

      padding-left: 15px;
      width: 90px;
      border-right: 1px solid white;
      
    }

    .abs{

      padding-left: 15px;
      width: 90px;
      border-right: 1px solid white;
        
    }

    .cals {
      padding-left: 15px;
    }

    .dtc {
         margin-top: -19px;
             margin-right: 130px;

             border-right: 1px solid white;

             padding-right: 10px;
    } 

    .totc {
          margin-top: -19px;
              
    margin-right: 90px !important;
    }


    .dicon {
      float: right;
      margin-top: -19px;
      margin-right: 23px;
      font-size: 18px;
      border-right: 1px solid white;
      border-left: 1px solid white;
      padding-left: 13px;
      padding-right: 13px;

        z-index: 1000;
    }

    .dicon:hover{
      color: red;
    }


   


   

   
</style>
<body>

 

   <?php

    require_once("header.html");

     require_once("sidenavbar.html");


   ?>

    

<br><br>



<div class="container"id="container" style="padding-left:0px">


 

<div class="main">

  <div style="float: right;
        margin-top: -20px;
    right: 70px;font-size: 15px;color: green;">
    <span> <?php echo date("d-M-Y") ?></span>
<span  id="ctym"></span>

   <span> GMT+5:30</span>

  </div>

  <span style="    position: absolute;
    left: 48%;
    margin-top: 0px;color: green;display: none;" class="upmsg"><i class="fa fa-check"></i>&nbsp;&nbsp;Successfully updated.</span>

    <span style="    position: absolute;
    left: 48%;
    margin-top: 0px;color: green;display: none;" class="upmsg1"><i class="fa fa-check"></i>&nbsp;&nbsp;Language changed to <span class="lanm"></span> </span>

  
 



<?php
 
 $sql4="UPDATE  `Open_Trades` SET `cps`=null WHERE 1";
        $con->query($sql4);

  

   $sql1 = "SELECT * FROM Open_Trades WHERE 1  group by Account_Number ";
   $result1=$con->query($sql1);

   $accn = [];

   while($row1 = $result1->fetch_assoc()) {

    array_push($accn,$row1["Account_Number"]);

      $sumpro = 0;
      $tot = 0;

    $sql12 = "SELECT SUM(Order_Profit) as pro FROM Open_Trades WHERE Account_Number='".$row1["Account_Number"]."' ";
   $result12=$con->query($sql12);
   while($row12 = $result12->fetch_assoc()) {
    $sumpro = $row12["pro"];
   }

   $sql13 = "SELECT COUNT(*) as tot FROM Open_Trades WHERE Account_Number='".$row1["Account_Number"]."' ";
   $result13=$con->query($sql13);
   while($row13 = $result13->fetch_assoc()) {
    $tot = $row13["tot"];
   }

   echo "<div style='margin-bottom:15px;'>";

    

    // $actloss = ( $sumpro * 100  )  /    $row1["Account_Balance"];

    // new1
    $actloss = $row1["UnrealisedProfitPercentage"];

    if($actloss>=0){


      if($actloss=="INF" || $actloss==INF || $actloss==null ){

         // echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'"><span class="bn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<span class="ac'.$row1["Account_Number"].'">'.$row1["Account_Number"].'</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<span class="ab'.$row1["Account_Number"].'">'.round($row1["Account_Balance"], 2). '</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: #0d4257;font-size:13px;"><span class="cal'.$row1["Account_Number"].'">NA</span></b>

         echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'">

          <div style="display:flex;padding-top: 5px;">
            <div  class="bns bn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'</div>
            <div class="acs ac'.$row1["Account_Number"].'">'.$row1["Account_Number"].'</div>
            <div class="abs ab'.$row1["Account_Number"].'">'.number_format($row1["Account_Balance"], 2,".",""). '</div>
            <div class="cals"><b style="color: #0d4257;font-size:13px;"><span class="cal'.$row1["Account_Number"].'">NA</span></b></div>
          </div>

       

      <i class="fa fa-plus picon1"></i>
      <i class="fa fa-minus micon dnone"></i>
      <i class="fa fa-trash dicon" data-toggle="tooltip" data-placement="top" title="Delete account and all its trades"></i>
     

      <span style="float: right;    font-size: 12px;
    margin-right: 10px;
    " class="totc tot'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="No. of Open Orders">'.$tot.'</span>

      <span style="float: right;    font-size: 12px;
   
    " class="dtc datet'.$row1["Account_Number"].'" >'.date('d-M-Y h:i:s',strtotime($row1["DateTime"])).'</span><span style="display:none;
    " class="dtc1" >'.date('d-M-Y H:i:s',strtotime($row1["DateTime"])).'</span>


    </button>
    
    <div class="coldiv r1div" id="div'.$row1["Account_Number"].'">';

      }else{

        if(round($actloss, 5)== "0" || round($actloss, 5)== "-0" || round($actloss, 5)== "+0" ){

           // echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].''.$row1["Account_Number"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.round($row1["Account_Balance"], 2). '&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: #0d4257;font-size:13px;">'.round($actloss, 5).'%</b>

            // echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'"><span class="bn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<span class="ac'.$row1["Account_Number"].'">'.$row1["Account_Number"].'</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<span class="ab'.$row1["Account_Number"].'">'.round($row1["Account_Balance"], 2). '</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: #0d4257;font-size:13px;"><span class="cal'.$row1["Account_Number"].'">'.round($actloss, 5).'%</span></b>


          echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'">

          <div style="display:flex;padding-top: 5px;">
            <div  class="bns bn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'</div>
            <div class="acs ac'.$row1["Account_Number"].'">'.$row1["Account_Number"].'</div>
            <div class="abs ab'.$row1["Account_Number"].'">'.number_format($row1["Account_Balance"], 2,".",""). '</div>
            <div class="cals"><b style="color: #0d4257;font-size:13px;"><span class="cal'.$row1["Account_Number"].'">'.number_format($actloss, 2,".","").' %</span></b></div>
          </div>

       

      <i class="fa fa-plus picon1"></i>
      <i class="fa fa-minus micon dnone"></i>
       <i class="fa fa-trash dicon" data-toggle="tooltip" data-placement="top" title="Delete account and all its trades"></i>
      

      <span style="float: right;    font-size: 12px;
    margin-right: 10px;
    " class="totc tot'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="No. of Open Orders">'.$tot.'</span>

     <span style="float: right;    font-size: 12px;
   
    " class="dtc datet'.$row1["Account_Number"].'" >'.date('d-M-Y h:i:s',strtotime($row1["DateTime"])).'</span><span style="display:none;
    " class="dtc1" >'.date('d-M-Y H:i:s',strtotime($row1["DateTime"])).'</span>


    </button>
    
    <div class="coldiv r1div" id="div'.$row1["Account_Number"].'">';

        }else{

           // echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.$row1["Account_Number"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.round($row1["Account_Balance"], 2). '&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: green;font-size:13px;">'.round($actloss, 5).'%</b>


          // echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'"><span style="position: absolute;left: 380px;">|</span><span style="position: absolute;left: 495px;">|</span><span style="position: absolute;left: 592px;">|</span><span class="bns bn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'</span><span class="acs ac'.$row1["Account_Number"].'">'.$row1["Account_Number"].'</span><span class="abs ab'.$row1["Account_Number"].'">'.round($row1["Account_Balance"], 2). '</span><b style="color: green;font-size:13px;"><span class="cals cal'.$row1["Account_Number"].'">'.round($actloss, 5).'%</span></b>


          echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'">

          <div style="display:flex;padding-top: 5px;">
            <div  class="bns bn'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="Broker Name">'.$row1["Broker_Name"].'</div>
            <div class="acs ac'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="Account Number">'.$row1["Account_Number"].'</div>
            <div class="abs ab'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="Account Balance">'.number_format($row1["Account_Balance"], 2,".",""). '</div>
            <div class="cals" data-toggle="tooltip" data-placement="top" title="Potential Unrealised Profit/Loss"><b style="color: green;font-size:13px;"><span class="cal'.$row1["Account_Number"].'">'.number_format($actloss, 2,".","").' %</span></b></div>
          </div>

       

      <i class="fa fa-plus picon1"></i>
      <i class="fa fa-minus micon dnone"></i>

       <i class="fa fa-trash dicon" data-toggle="tooltip" data-placement="top" title="Delete account and all its trades"></i>

      <span style="float: right;    font-size: 12px;
    margin-right: 10px;
    " class="totc tot'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="No. of Open Orders">'.$tot.'</span>

     <span style="float: right;    font-size: 12px;
   
    " class="dtc datet'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="This is the time when data was last sent from Metatrader.">'.date('d-M-Y h:i:s',strtotime($row1["DateTime"])).'</span><span style="display:none;
    " class="dtc1" >'.date('d-M-Y H:i:s',strtotime($row1["DateTime"])).'</span>

    </button>
    
    <div class="coldiv r1div" id="div'.$row1["Account_Number"].'">';

        }


        

      }

      

    }else{

      if($actloss=="INF" || $actloss==INF || $actloss==null ){

         // echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.$row1["Account_Number"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.round($row1["Account_Balance"], 2). '&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: #0d4257;font-size:13px;">NA</b>

        // echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'"><span class="bn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<span class="ac'.$row1["Account_Number"].'">'.$row1["Account_Number"].'</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<span class="ab'.$row1["Account_Number"].'">'.round($row1["Account_Balance"], 2). '</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: #0d4257;font-size:13px;"><span class="cal'.$row1["Account_Number"].'">NA</span></b>


        // echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'">

        //   <div style="display:flex;padding-top: 5px;">
        //     <div  class="bns bn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'</div>
        //     <div class="acs ac'.$row1["Account_Number"].'">'.$row1["Account_Number"].'</div>
        //     <div class="abs ab'.$row1["Account_Number"].'">'.number_format($row1["Account_Balance"], 2,".",""). '</div>
        //     <div class="cals"><b style="color: #0d4257;font-size:13px;"><span class="cal'.$row1["Account_Number"].'">NA</span></b></div>
        //   </div>

        echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'">

          <div style="display:flex;padding-top: 5px;">
            <div  class="bns bn'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="Broker Name">'.$row1["Broker_Name"].'</div>
            <div class="acs ac'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="Account Number">'.$row1["Account_Number"].'</div>
            <div class="abs ab'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="Account Balance">'.number_format($row1["Account_Balance"], 2,".",""). '</div>
            <div class="cals" data-toggle="tooltip" data-placement="top" title="Potential Unrealised Profit/Loss"><b style="color: #0d4257;font-size:13px;"><span class="cal'.$row1["Account_Number"].'">NA</span></b></div>
          </div>

      

      <i class="fa fa-plus picon1"></i>
      <i class="fa fa-minus micon dnone"></i>
       <i class="fa fa-trash dicon" data-toggle="tooltip" data-placement="top" title="Delete account and all its trades"></i>
     

      <span style="float: right;    font-size: 12px;
    margin-right: 10px;
    " class="totc tot'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="No. of Open Orders">'.$tot.'</span>

      <span style="float: right;    font-size: 12px;
   
    " class="dtc datet'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="This is the time when data was last sent from Metatrader.">'.date('d-M-Y h:i:s',strtotime($row1["DateTime"])).'</span><span style="display:none;
    " class="dtc1" >'.date('d-M-Y H:i:s',strtotime($row1["DateTime"])).'</span>



    </button>
    
    <div class="coldiv r1div" id="div'.$row1["Account_Number"].'">';

      }else{

        if(round($actloss, 5)== "0" || round($actloss, 5)== "-0" || round($actloss, 5)== "+0" ){

           // echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.$row1["Account_Number"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.round($row1["Account_Balance"], 2). '&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: #0d4257;font-size:13px;">'.round($actloss, 5).'%</b>

           // echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'"><span class="bn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<span class="ac'.$row1["Account_Number"].'">'.$row1["Account_Number"].'</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<span class="ab'.$row1["Account_Number"].'">'.round($row1["Account_Balance"], 2). '</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: #0d4257;font-size:13px;"><span class="cal'.$row1["Account_Number"].'">'.round($actloss, 5).'%</span></b>


          //  echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'">

          // <div style="display:flex;padding-top: 5px;">
          //   <div  class="bns bn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'</div>
          //   <div class="acs ac'.$row1["Account_Number"].'">'.$row1["Account_Number"].'</div>
          //   <div class="abs ab'.$row1["Account_Number"].'">'.number_format($row1["Account_Balance"], 2,".",""). '</div>
          //   <div class="cals"><b style="color: #0d4257;font-size:13px;"><span class="cal'.$row1["Account_Number"].'">'.number_format($actloss, 2,".","").' %</span></b></div>
          // </div>

           echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'">

          <div style="display:flex;padding-top: 5px;">
            <div  class="bns bn'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="Broker Name">'.$row1["Broker_Name"].'</div>
            <div class="acs ac'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="Account Number">'.$row1["Account_Number"].'</div>
            <div class="abs ab'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="Account Balance">'.number_format($row1["Account_Balance"], 2,".",""). '</div>
            <div class="cals" data-toggle="tooltip" data-placement="top" title="Potential Unrealised Profit/Loss"><b style="color: #0d4257;font-size:13px;"><span class="cal'.$row1["Account_Number"].'">'.number_format($actloss, 2,".","").' %</span></b></div>
          </div>

      

      <i class="fa fa-plus picon1"></i>
      <i class="fa fa-minus micon dnone"></i>

      <i class="fa fa-trash dicon" data-toggle="tooltip" data-placement="top" title="Delete account and all its trades"></i>

      <span style="float: right;    font-size: 12px;
    margin-right: 10px;
    " class="totc tot'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="No. of Open Orders">'.$tot.'</span>

       <span style="float: right;    font-size: 12px;
   
    " class="dtc datet'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="This is the time when data was last sent from Metatrader.">'.date('d-M-Y h:i:s',strtotime($row1["DateTime"])).'</span><span style="display:none;
    " class="dtc1" >'.date('d-M-Y H:i:s',strtotime($row1["DateTime"])).'</span>


    </button>
    
    <div class="coldiv r1div" id="div'.$row1["Account_Number"].'">';

        }else{

           // echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.$row1["Account_Number"].'&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;'.round($row1["Account_Balance"], 2). '&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: red;font-size:13px;">'.round($actloss, 5).'%</b>


           // echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'"><span class="bn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<span class="ac'.$row1["Account_Number"].'">'.$row1["Account_Number"].'</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<span class="ab'.$row1["Account_Number"].'">'.round($row1["Account_Balance"], 2). '</span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: red;font-size:13px;"><span class="cal'.$row1["Account_Number"].'">'.round($actloss, 5).'%</span></b>


          // echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'">

          // <div style="display:flex;padding-top: 5px;">
          //   <div  class="bns bn'.$row1["Account_Number"].'">'.$row1["Broker_Name"].'</div>
          //   <div class="acs ac'.$row1["Account_Number"].'">'.$row1["Account_Number"].'</div>
          //   <div class="abs ab'.$row1["Account_Number"].'">'.number_format($row1["Account_Balance"], 2,".",""). '</div>
          //   <div class="cals"><b style="color: red;font-size:13px;"><span class="cal'.$row1["Account_Number"].'">'.number_format($actloss, 2,".","").' %</span></b></div>
          // </div>



           echo '<button class="btn btn-primary vsb r1btn" data="'.$row1["Account_Number"].'" id="btn'.$row1["Account_Number"].'">

          <div style="display:flex;padding-top: 5px;">
            <div  class="bns bn'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="Broker Name">'.$row1["Broker_Name"].'</div>
            <div class="acs ac'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="Account Number">'.$row1["Account_Number"].'</div>
            <div class="abs ab'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="Account Balance">'.number_format($row1["Account_Balance"], 2,".",""). '</div>
            <div class="cals" data-toggle="tooltip" data-placement="top" title="Potential Unrealised Profit/Loss"><b style="color: red;font-size:13px;"><span class="cal'.$row1["Account_Number"].'">'.number_format($actloss, 2,".","").' %</span></b></div>
          </div>


      

      <i class="fa fa-plus picon1"></i>
      <i class="fa fa-minus micon dnone"></i>

       <i class="fa fa-trash dicon" data-toggle="tooltip" data-placement="top" title="Delete account and all its trades"></i>

      <span style="float: right;    font-size: 12px;
    margin-right: 10px;
    " class="totc tot'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="No. of Open Orders">'.$tot.'</span>



   <span style="float: right;    font-size: 12px;
   
    " class="dtc datet'.$row1["Account_Number"].'" data-toggle="tooltip" data-placement="top" title="This is the time when data was last sent from Metatrader.">'.date('d-M-Y h:i:s',strtotime($row1["DateTime"])).'</span><span style="display:none;
    " class="dtc1" >'.date('d-M-Y H:i:s',strtotime($row1["DateTime"])).'</span>


    </button>
    
    <div class="coldiv r1div" id="div'.$row1["Account_Number"].'">';

        }

        

      }

      

    }

   

    echo '<table class="table table-bordered" class="table" id="'.$row1["Account_Number"].'">
    <thead>
  <tr>
    <th><center>Sl.No.</center></th>
    
   
    <th>Ticket </th>
    <th>Symbol</th>
    <th>Type</th>
    <th>Lots </th>
    <th>Stop Loss</th>
    <th>Take Profit</th>
    
    <th>Open Price</th>
    <th>Open&nbsp;Time&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
    <th>Current Price</th>
    
    <th>Swap</th>
    <th>Commission</th>
    <th>Profit</th>
    <th>Comment</th>
    <th>Magic Number</th>
   
  </tr>
</thead>
<tbody>';


$i1 = 1;

   $sql = "SELECT * FROM Open_Trades WHERE Account_Number='".$row1["Account_Number"]."' order by Order_Symbol asc ";
   $result=$con->query($sql);
   while($row = $result->fetch_assoc()) {

    $tot++;


   echo "<tr class='tr' id='".$row["SN"]."'>";
  
    echo "<td style='text-align:center;'>".$i1."</td>";
    // echo "<td>".$row["Broker_Name"]."</td>";
    // echo "<td>".$row["Account_Number"]."</td>";
    echo "<td>".$row["Order_Ticket"]."</td>";
    echo "<td>".$row["Order_Symbol"]."</td>";


    if($row["Order_Type"]=="BUY"){

     echo "<td style='background: lightgreen;'>Buy</td>";

   }else{
    echo "<td style='background: #f59a9a;'>Sell</td>";
   }

    echo "<td class='righta'>".number_format($row["Order_Lots"], 2,".","")."</td>";
    echo "<td class='righta'>".round($row["Order_StopLoss"],5)."</td>";
    echo "<td class='righta'>".round($row["Order_TakeProfit"],5)."</td>";
    // echo "<td>".$row["Order_Expiration"]."</td>";
    echo "<td class='righta'>".round($row["Order_OpenPrice"],5)."</td>";
    echo "<td>".$row["Order_OpenTime"]."</td>";
    echo "<td class='righta'><span>".round($row["Order_ClosePrice"],5)."<span style='display:none;' class='cps".$row["Order_Ticket"]."'></span></span></td>";
    // echo "<td>".$row["Order_CloseTime"]."</td>";
    echo "<td class='righta'>".round($row["Order_Swap"],5)."</td>";
    echo "<td class='righta'>".round($row["Order_Commission"],5)."</td>";



    $op = number_format($row["Order_Profit"], 2,".","");

     if($op>=0){
      echo "<td class='righta' style='background: lightgreen;'>".$op."</td>";
     }else{
      echo "<td class='righta' style='background: #f59a9a;'>".$op."</td>";
     }

    

    echo "<td>".$row["Order_Comment"]."</td>";
    echo "<td style='text-align: left;'>".$row["Order_MagicNumber"]."</td>";
   
    

    
    echo "</tr>";

    $i1++;

  }


echo '</tbody>
</table>';


    echo'</div>';

    echo'</div>';

   }

   json_encode($accn);

  

   if(sizeof($accn)==0){
    echo "<p style='    position: absolute;
    left: 46%;
    top: 30%;
    font-size: 20px;' class='nda'>No Data Available!</p>";
   }else{
    echo "<p style='    position: absolute;
    left: 46%;
    top: 30%;
    font-size: 20px;display:none;' class='nda'>No Data Available!</p>";
   }




    $sql11 = "SELECT * FROM setting WHERE 1";
   $result11=$con->query($sql11);

   $time = "";

   while($row11 = $result11->fetch_assoc()) {
    $time = $row11["Time"];
   }





    ?>


 








</div>

</div>




<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">MT4 Account Data - Live Monitoring</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">

        <div class="ne">
                  
        </div>
        
        <form class="form-horizontal form" style="position: relative;
    left: 91px;"></form>



        <button class="btn btn-success addbtn" type="button" style="    position: relative;
    left: 100px;
    margin-bottom: 10px;    width: 277px;" ><i class="fa fa-plus"></i>&nbsp; Add Another MT4 Account</button>


      </div>

      <!-- Modal footer -->
      <div class="modal-footer">

        <center class="msgs" style="color:green;position: absolute;
    left: 45%;display: none;">Account Saved!</center>
        <!-- <center class="dupmsg1" style="color:red;position: absolute;
    left: 45%;display: none;">This MT4 account number is already present in database.</center> -->
        <div  class="dupmsg1" style="position: absolute; left: 30%; margin-top:0%; color:red; display: none;">MT4 account number already exists!</div>
        <!-- <div  class="dupmsg1" style="position: absolute; left: 30%; color:red; display: none;"></div> -->
        <!-- <center class="dupmsg2" style="color:red;position: absolute;
    left: 45%;display: none;">Account already exists!</center> -->
        <!-- <div  class="dupmsg2" style="position: absolute; left: 35%; margin-top:4%; color:red; display: none;">Duplicate MT4 account!</div> -->

        <button type="button" class="btn btn-primary" data-dismiss="modal" style="    position: relative;
    right: 98px;">Done</button>
        <!-- <button id="donebtn" type="button" class="btn btn-primary" style="    position: relative;
    right: 98px;">Done</button> -->
      </div>

    </div>
  </div>
</div>










<!-- The Modal -->
<div class="modal" id="delModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">MT4 Account Data - Live Monitoring</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">

      
        <p>Do you really want to delete this Account?</p>


      </div>

      <!-- Modal footer -->
      <div class="modal-footer">

        <center class="delmsg" style="color:red;position: absolute;
    left: 45%;display: none;">Account Deleted!</center>

        <button type="button" class="btn btn-success yesbtn">Yes</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>




  


<script>





  


   $('.table').DataTable({
        "iDisplayLength": 10,
        
        "language": {
          "search": "Search"
        },
        

  });
  



 


$(".ot").addClass("active");

var open = [];

$("body").delegate(".r1btn","click",function(){

      $(this).next(".r1div").slideToggle();

      if($(this).children(".picon1").hasClass("dnone")){
        $(this).children(".picon1").removeClass("dnone");
        $(this).children(".micon").addClass("dnone");

        var removeItem = $(this).attr("data");

        open = jQuery.grep(open, function(value) {
          return value != removeItem;
        });

        

      }else{
        $(this).children(".picon1").addClass("dnone");
        $(this).children(".micon").removeClass("dnone");
        if(jQuery.inArray($(this).attr("data"), open) !== -1){
          
        }else{
          open.push($(this).attr("data"));
        }
        
      }

     


    });


// setInterval (function(){


//   $.post("ot_fetch.php",
//       {
//         data: JSON.stringify(open)
//       },function(data)
//       {
//         $(".main").html(data);

//         $('.table').DataTable({
//         "iDisplayLength": 100,
        
//         "language": {
//           "search": "Search"
//         }

//   });

//       });
  

//   },2000);

  







var aca = JSON.parse('<?php echo json_encode($accn); ?>');


var time = Number('<?php echo $time; ?>');

var pflag =0;



setInterval (function(){

  var feedContainer = $('#container');

$.post("acc.php",
      {
       
      },function(data)
      {
        var darr = JSON.parse(data);

      

        if(darr.length==0){
          $(".r1btn").css("display", "none");
          $(".nda").css("display", "block");
        }else{

          $(".nda").css("display", "none");
        }
        
        for (var i = 0; i < darr.length; i++) {

          if(jQuery.inArray(darr[i], aca) !== -1){
             

           }else{
            aca.push(darr[i]);

            // $(".main").append('<button class="btn btn-primary vsb r1btn" data="'+darr[i]+'"><span class="bn'+darr[i]+'"></span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp; <span class="ac'+darr[i]+'"></span>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp; <span class="ab'+darr[i]+'"></span> &nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<b style="color: #0d4257;font-size:13px;"><span class="cal'+darr[i]+'"></span></b>  <i class="fa fa-plus picon1"></i>  <i class="fa fa-minus micon dnone"></i>     <span style="float: right;    font-size: 12px;    margin-right: 10px;  " class="tot'+darr[i]+'"></span> <span style="float: right;    font-size: 12px;   " class="datet'+darr[i]+'" >&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;</span>   </button><div class="coldiv r1div "><table class="table table-bordered" class="table" id="'+darr[i]+'" ><thead><tr><th><center>Sl.No.</center></th><th>Ticket </th><th>Symbol</th><th>Type</th><th>Lots </th><th>Stop Loss</th><th>Take Profit</th><th>Open Price</th> <th>Open&nbsp;Time&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th><th>Current Price</th><th>Swap</th><th>Commission</th><th>Profit</th>   <th>Comment</th>  <th>Magic Number</th> </tr></thead><tbody></tbody></table></div><br><br>');


            $(".main").append('<div style="margin-bottom:15px;"><button class="btn btn-primary vsb r1btn" data="'+darr[i]+'" id="btn'+darr[i]+'"><div style="display:flex;padding-top: 5px;"><div data-toggle="tooltip" data-placement="top" title="Broker Name" class="bns bn'+darr[i]+'"></div><div data-toggle="tooltip" data-placement="top" title="Account Number" class="acs ac'+darr[i]+'"></div><div data-toggle="tooltip" data-placement="top" title="Account Balance" class="abs ab'+darr[i]+'"></div><div  data-toggle="tooltip" data-placement="top" title="Potential Unrealised Profit/Loss" class="cals"><b style="color: #0d4257;font-size:13px;"><span class="cal'+darr[i]+'">NA</span></b></div></div><i class="fa fa-plus picon1"></i><i class="fa fa-minus micon dnone"></i> <i class="fa fa-trash dicon" data-toggle="tooltip" data-placement="top" title="Delete account and all its trades"></i><span style="float: right;    font-size: 12px;margin-right: 10px;    " data-toggle="tooltip" data-placement="top" title="No. of Open Orders" class="totc tot'+darr[i]+'" ></span><span style="float: right;    font-size: 12px;" class="dtc datet'+darr[i]+'" data-toggle="tooltip" data-placement="top" title="This is the time when data was last sent from Metatrader."></span><span style="display:none;" class="dtc1" ></span></button><div class="coldiv r1div "><table class="table table-bordered" class="table" id="'+darr[i]+'" ><thead><tr><th><center>Sl.No.</center></th><th>Ticket </th><th>Symbol</th><th>Type</th><th>Lots </th><th>Stop Loss</th><th>Take Profit</th><th>Open Price</th> <th>Open&nbsp;Time&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th><th>Current Price</th><th>Swap</th><th>Commission</th><th>Profit</th>   <th>Comment</th>  <th>Magic Number</th> </tr></thead><tbody></tbody></table></div></div>');


           }
        }


      });





for (var i = 0; i < aca.length; i++) {

  var acc = aca[i];
  

 
   $.post("ot_fetch_new.php",
      {
         acc
      },function(data)
      {
        var arr = $.parseJSON(data);
        var j = 0;
        

      

         if( arr.length==0){

          $.post("ot_fetch_new.php",
      {
         acc
      },function(data1)
      {

        var arr1 = $.parseJSON(data1);

        if( arr1.length==0){

          $('#btn'+acc).css("display", "none");
          $('#div'+acc).css("display", "none");

        }

        });

          

         }else{

           var aac = arr[0]["Account_Number"];

            for (var i = 0, len = arr.length; i < len; i++) {
                  // console.log("arr[i]", arr[i]["Account_Number"]);

                  var olp = $("#cps"+arr[i]["Order_Ticket"]).parent("td").text();
                  var olp1 = $("#cps"+arr[i]["Order_Ticket"]).parent("span").parent("td").text();
                  console.log("olp1", olp1);


                  if(i==0){
                      $('#'+arr[i]["Account_Number"]).dataTable().fnClearTable();
                    
                  }

                 

                  j++;

                  



                 
                  
              //     if(pflag>1){


                  

              //      if(Number(olp1)>Number(arr[i]["Order_ClosePrice1"])){
              //       $("#cps"+arr[i]["Order_Ticket"]).parent("td").css("background", "#f59a9a");
                      
              //         if(arr[i]["Order_Type"]=="BUY"){
              //       $('#'+aac).DataTable().rows.add(
              //    [[ j, arr[i]["Order_Ticket"], arr[i]["Order_Symbol"], "Buy", arr[i]["Order_Lots"], arr[i]["Order_StopLoss"], arr[i]["Order_TakeProfit"], arr[i]["Order_OpenPrice"], arr[i]["Order_OpenTime"], "<span style='color:red;'>"+arr[i]["Order_ClosePrice"]+"</span>", arr[i]["Order_Swap"], arr[i]["Order_Commission"], arr[i]["Order_Profit"], arr[i]["Order_Comment"], arr[i]["Order_MagicNumber"] ] ],
              // ).draw(); 

              //     }else{
              //       $('#'+aac).DataTable().rows.add(
              //    [[ j, arr[i]["Order_Ticket"], arr[i]["Order_Symbol"], "Sell", arr[i]["Order_Lots"], arr[i]["Order_StopLoss"], arr[i]["Order_TakeProfit"], arr[i]["Order_OpenPrice"], arr[i]["Order_OpenTime"], "<span style='color:red;'>"+arr[i]["Order_ClosePrice"]+"</span>", arr[i]["Order_Swap"], arr[i]["Order_Commission"], arr[i]["Order_Profit"], arr[i]["Order_Comment"], arr[i]["Order_MagicNumber"] ] ],
              // ).draw(); 

              //     }

              //      }else if(Number(olp1)<Number(arr[i]["Order_ClosePrice1"])){
              //       $("#cps"+arr[i]["Order_Ticket"]).parent("td").css("background", "lightgreen");
                    
              //       if(arr[i]["Order_Type"]=="BUY"){
              //       $('#'+aac).DataTable().rows.add(
              //    [[ j, arr[i]["Order_Ticket"], arr[i]["Order_Symbol"], "Buy", arr[i]["Order_Lots"], arr[i]["Order_StopLoss"], arr[i]["Order_TakeProfit"], arr[i]["Order_OpenPrice"], arr[i]["Order_OpenTime"], "<span style='color:green;'>"+arr[i]["Order_ClosePrice"]+"</span>", arr[i]["Order_Swap"], arr[i]["Order_Commission"], arr[i]["Order_Profit"], arr[i]["Order_Comment"], arr[i]["Order_MagicNumber"] ] ],
              // ).draw(); 

              //     }else{
              //       $('#'+aac).DataTable().rows.add(
              //    [[ j, arr[i]["Order_Ticket"], arr[i]["Order_Symbol"], "Sell", arr[i]["Order_Lots"], arr[i]["Order_StopLoss"], arr[i]["Order_TakeProfit"], arr[i]["Order_OpenPrice"], arr[i]["Order_OpenTime"], "<span style='color:green;'>"+arr[i]["Order_ClosePrice"]+"</span>", arr[i]["Order_Swap"], arr[i]["Order_Commission"], arr[i]["Order_Profit"], arr[i]["Order_Comment"], arr[i]["Order_MagicNumber"] ] ],
              // ).draw(); 

              //     }

              //      }else{
              //       $("#cps"+arr[i]["Order_Ticket"]).parent("td").css("background", "white");
                    
              //       if(arr[i]["Order_Type"]=="BUY"){
              //       $('#'+aac).DataTable().rows.add(
              //    [[ j, arr[i]["Order_Ticket"], arr[i]["Order_Symbol"], "Buy", arr[i]["Order_Lots"], arr[i]["Order_StopLoss"], arr[i]["Order_TakeProfit"], arr[i]["Order_OpenPrice"], arr[i]["Order_OpenTime"], "<span style='color:black;'>"+arr[i]["Order_ClosePrice"]+"</span>", arr[i]["Order_Swap"], arr[i]["Order_Commission"], arr[i]["Order_Profit"], arr[i]["Order_Comment"], arr[i]["Order_MagicNumber"] ] ],
              // ).draw(); 

              //     }else{
              //       $('#'+aac).DataTable().rows.add(
              //    [[ j, arr[i]["Order_Ticket"], arr[i]["Order_Symbol"], "Sell", arr[i]["Order_Lots"], arr[i]["Order_StopLoss"], arr[i]["Order_TakeProfit"], arr[i]["Order_OpenPrice"], arr[i]["Order_OpenTime"], "<span style='color:black;'>"+arr[i]["Order_ClosePrice"]+"</span>", arr[i]["Order_Swap"], arr[i]["Order_Commission"], arr[i]["Order_Profit"], arr[i]["Order_Comment"], arr[i]["Order_MagicNumber"] ] ],
              // ).draw(); 

              //     }

              //      }


              //    }else{

              //      $('#'+aac).DataTable().rows.add(
              //    [[ j, arr[i]["Order_Ticket"], arr[i]["Order_Symbol"], "Sell", arr[i]["Order_Lots"], arr[i]["Order_StopLoss"], arr[i]["Order_TakeProfit"], arr[i]["Order_OpenPrice"], arr[i]["Order_OpenTime"], "<span style='color:black;'>"+arr[i]["Order_ClosePrice"]+"</span>", arr[i]["Order_Swap"], arr[i]["Order_Commission"], arr[i]["Order_Profit"], arr[i]["Order_Comment"], arr[i]["Order_MagicNumber"] ] ],
              // ).draw(); 


              //    }


              if(arr[i]["Order_Type"]=="BUY"){
                    $('#'+aac).DataTable().rows.add(
                 [[ j, arr[i]["Order_Ticket"], arr[i]["Order_Symbol"], "Buy", arr[i]["Order_Lots"], arr[i]["Order_StopLoss"], arr[i]["Order_TakeProfit"], arr[i]["Order_OpenPrice"], arr[i]["Order_OpenTime"], "<span style='color:black;'>"+arr[i]["Order_ClosePrice"]+"</span>", arr[i]["Order_Swap"], arr[i]["Order_Commission"], arr[i]["Order_Profit"], arr[i]["Order_Comment"], arr[i]["Order_MagicNumber"] ] ],
              ).draw(); 

                  }else{
                    $('#'+aac).DataTable().rows.add(
                 [[ j, arr[i]["Order_Ticket"], arr[i]["Order_Symbol"], "Sell", arr[i]["Order_Lots"], arr[i]["Order_StopLoss"], arr[i]["Order_TakeProfit"], arr[i]["Order_OpenPrice"], arr[i]["Order_OpenTime"], "<span style='color:black;'>"+arr[i]["Order_ClosePrice"]+"</span>", arr[i]["Order_Swap"], arr[i]["Order_Commission"], arr[i]["Order_Profit"], arr[i]["Order_Comment"], arr[i]["Order_MagicNumber"] ] ],
              ).draw(); 

                  }

                  

                   $('.bn'+aac).text(arr[i]["Broker_Name"]);
                   $('.ac'+aac).text(arr[i]["Account_Number"]);
                   $('.ab'+aac).text(arr[i]["Account_Balance"]);
                   $('.cal'+aac).html(arr[i]["Cal"]);
                   $('.tot'+aac).text(arr[i]["Tot"]);
                   $('.datet'+aac).html(arr[i]["Datet"]+"");
                   $('.datet'+aac).siblings(".dtc1").text(arr[i]["Datet1"]);



              }


              



                $('tr').each(function (i, el) {
                  var $tds = $(this).find('td'),
                   type = $tds.eq(3).text();
                   op = $tds.eq(12).text();
                   crr = $tds.eq(9).children("span").text();

                    if(type=="Buy"){
                        $tds.eq(3).css("background", "lightgreen");
                      }else{
                        $tds.eq(3).css("background", "#f59a9a");
                      }

                       if(op>=0){
                        $tds.eq(12).css("background", "lightgreen");
                      }else{
                        $tds.eq(12).css("background", "#f59a9a");
                      }

                      if(crr==1){
                        $tds.eq(9).css("background", "lightgreen");
                      }else if(crr==2){
                        $tds.eq(9).css("background", "#f59a9a");
                      }else{
                         $tds.eq(9).css("background", "#fff");
                      }


                     
                      $tds.eq(0).css("text-align","center");

                      $tds.eq(4).addClass("righta");
                      $tds.eq(5).addClass("righta");
                      $tds.eq(6).addClass("righta");
                      $tds.eq(7).addClass("righta");
                     
                      $tds.eq(9).addClass("righta");
                      $tds.eq(10).addClass("righta");
                      $tds.eq(11).addClass("righta");
                      $tds.eq(12).addClass("righta");


                 });




                $(".r1btn").each(function(){
  var dt = $.trim($(this).children(".dtc1").text());
    dt = dt.replace("|", "");
    dt = $.trim(dt);

   var date = moment(dt).format('DD-MM-YYYY');
   var date1 = moment().format('DD-MM-YYYY');
   
    if(date1 == date){
       var time = moment(dt).format('HH:mm a');
       var time1 = moment().format('hh:mm a');

       //  console.log("dt",dt);
       //  console.log("time",time);
       // console.log("time1",time1);

       

      var startTime = moment(time, 'HH:mm a');
      var endTime = moment(time1, 'HH:mm a');

      var duration = moment.duration(endTime.diff(startTime));

      var minutes = parseInt(duration.asMinutes()) % 60;

       var hours = parseInt(duration.asHours());

        
        if(minutes>1){
          // $(this).children("div").children(".bns").css("color","red");
          // $(this).children("div").children(".acs").css("color","red");
          // $(this).children("div").children(".abs").css("color","red");
          // $(this).children(".totc").css("color","red");
          $(this).children(".dtc").css("color","red");
        }else{
          // $(this).children("div").children(".bns").css("color","white");
          // $(this).children("div").children(".acs").css("color","white");
          // $(this).children("div").children(".abs").css("color","white");
          // $(this).children(".totc").css("color","white");
          $(this).children(".dtc").css("color","white");
        }



    }else{
       // $(this).children("div").children(".bns").css("color","red");
       //    $(this).children("div").children(".acs").css("color","red");
       //    $(this).children("div").children(".abs").css("color","red");
       //    $(this).children(".totc").css("color","red");
          $(this).children(".dtc").css("color","red");
    }

  

});





          }




       
      });







}

  


pflag = pflag+1;





 },time);










function displayTime() {
  let current_time = moment().format("HH:mm:ss")

$("#ctym").text(current_time);
    setTimeout(displayTime, 1000);
}

$(document).ready(function() {
    displayTime();
});




$(".r1btn").each(function(){
  var dt = $.trim($(this).children(".dtc1").text());
    dt = dt.replace("|", "");
    dt = $.trim(dt);

   var date = moment(dt).format('DD-MM-YYYY');
   var date1 = moment().format('DD-MM-YYYY');
   
    if(date1 == date){
       var time = moment(dt).format('HH:mm a');
       var time1 = moment().format('hh:mm a');

       

       

      var startTime = moment(time, 'HH:mm a');
      var endTime = moment(time1, 'HH:mm a');

      var duration = moment.duration(endTime.diff(startTime));

      var minutes = parseInt(duration.asMinutes()) % 60;

       var hours = parseInt(duration.asHours());



        
        if(minutes>1){
          // $(this).children("div").children(".bns").css("color","red");
          // $(this).children("div").children(".acs").css("color","red");
          // $(this).children("div").children(".abs").css("color","red");
          // $(this).children(".totc").css("color","red");
          $(this).children(".dtc").css("color","red");
        }else{
          // $(this).children("div").children(".bns").css("color","white");
          // $(this).children("div").children(".acs").css("color","white");
          // $(this).children("div").children(".abs").css("color","white");
          // $(this).children(".totc").css("color","white");
          $(this).children(".dtc").css("color","white");
        }



    }else{
       // $(this).children("div").children(".bns").css("color","red");
       //    $(this).children("div").children(".acs").css("color","red");
       //    $(this).children("div").children(".abs").css("color","red");
       //    $(this).children(".totc").css("color","red");
          $(this).children(".dtc").css("color","red");
    }

  

});


var accnum = "";
var delt = "";
$("body").delegate(".dicon","click",function(){

  accnum = $(this).parent("button").attr("data");

  delt = this;

  $("#delModal").modal();


});

  
  $("body").delegate(".yesbtn","click",function(){



      $.post("dela.php",
      {
       accnum
      },function(data)
      {
        $(".delmsg").fadeIn(1000).fadeOut(3000);

        $("#delModal").modal("toggle");   

        $(delt).parent("button").css("display","none");
        $("#div"+accnum).css("display","none");

    });


  
  


});



$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});


setInterval (function(){
    $('tr').each(function (i, el) {
                  var $tds = $(this).find('td'),
                   type = $tds.eq(3).text();
                   op = $tds.eq(12).text();
                   crr = $tds.eq(9).children("span").text();

                    if(type=="Buy"){
                        $tds.eq(3).css("background", "lightgreen");
                      }else{
                        $tds.eq(3).css("background", "#f59a9a");
                      }

                       if(op>=0){
                        $tds.eq(12).css("background", "lightgreen");
                      }else{
                        $tds.eq(12).css("background", "#f59a9a");
                      }

                      if(crr==1){
                        $tds.eq(9).css("background", "lightgreen");
                      }else if(crr==2){
                        $tds.eq(9).css("background", "#f59a9a");
                      }else{
                         $tds.eq(9).css("background", "#fff");
                      }


                     
                      $tds.eq(0).css("text-align","center");

                      $tds.eq(4).addClass("righta");
                      $tds.eq(5).addClass("righta");
                      $tds.eq(6).addClass("righta");
                      $tds.eq(7).addClass("righta");
                     
                      $tds.eq(9).addClass("righta");
                      $tds.eq(10).addClass("righta");
                      $tds.eq(11).addClass("righta");
                      $tds.eq(12).addClass("righta");


                 });

},100);









// var arr = new Array({'Broker_Name':'Test008','Account_Number':'223232321','Account_Balance':'3132','Order_Ticket':'221','Order_Symbol':'Order_Symbol','Order_Type':'Order_Type','Order_Lots':'121','Order_StopLoss':'323','Order_TakeProfit':'4343','Order_Expiration':'66','Order_OpenPrice':'2923','Order_OpenTime':'3729','Order_ClosePrice':'68169','Order_CloseTime':'23232','Order_Swap':'63822','Order_Commission':'827','Order_Profit':'6398267','Order_Comment':'dhsk','Order_MagicNumber':'3213','DateTime':'2022-06-10 10:04:37.000000', 'UnrealisedProfitPercentage':'8'});


// $.ajax({
//         url: "Insert_Open_Trades.php",
//         type: "POST",
//         dataType: 'json',
//         data: JSON.stringify(arr),
//         success: function(response){}

//        });


</script>

</body>
</html>

